import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../server';
import { AppError } from './errorHandler';
import { UserRole } from '@prisma/client';

export interface JwtPayload {
  userId: string;
  role: UserRole;
  companyId?: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

export function authenticate(req: Request, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return next(new AppError('Нэвтрэх шаардлагатай', 401));
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JwtPayload;
    req.user = decoded;
    next();
  } catch {
    return next(new AppError('Token хүчингүй эсвэл хугацаа дууссан', 401));
  }
}

export function authorize(...roles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(new AppError('Нэвтрэх шаардлагатай', 401));
    if (!roles.includes(req.user.role)) {
      return next(new AppError('Эрх хүрэлцэхгүй байна', 403));
    }
    next();
  };
}

export function authorizeCompany(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) return next(new AppError('Нэвтрэх шаардлагатай', 401));
  if (req.user.role === 'SUPER_ADMIN') return next();

  const companyId = req.params.companyId || req.body.companyId;
  if (companyId && req.user.companyId !== companyId) {
    return next(new AppError('Энэ компанид хандах эрхгүй байна', 403));
  }
  next();
}

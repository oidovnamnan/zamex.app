import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // 1. Platform Settings
  const configHash = await bcrypt.hash('zamex_config_2025', 12);
  await prisma.platformSettings.create({
    data: { configPasswordHash: configHash },
  });
  console.log('✅ Platform settings created');

  // 2. Super Admin
  const adminPassword = await bcrypt.hash('admin123456', 12);
  const admin = await prisma.user.create({
    data: {
      phone: '99112233',
      firstName: 'Намнансүрэн',
      password: adminPassword,
      role: 'SUPER_ADMIN',
      otpVerified: true,
    },
  });
  console.log('✅ Super admin created:', admin.phone);

  // 3. Demo Cargo Company
  const company = await prisma.company.create({
    data: {
      name: 'Cargo Express',
      nameEn: 'Cargo Express',
      slug: 'cargo-express',
      codePrefix: 'CGE',
      phone: '77001122',
      description: 'Хятад-Монгол карго тээвэр. Хурдан, найдвартай.',
    },
  });
  console.log('✅ Company created:', company.name);

  // 4. Workflow Settings
  await prisma.workflowSettings.create({
    data: { companyId: company.id },
  });

  // 5. Warehouses
  await prisma.warehouse.createMany({
    data: [
      {
        companyId: company.id,
        type: 'CHINA',
        name: 'Эрээн агуулах',
        address: '内蒙古自治区 锡林郭勒盟 二连浩特市 XX路XX号 Cargo Express 转运仓',
        city: '二连浩特',
        phone: '13800001234',
        receiverName: '张三',
      },
      {
        companyId: company.id,
        type: 'MONGOLIA',
        name: 'УБ агуулах',
        address: 'БЗД, 3-р хороо, Жуковын гудамж 12',
        city: 'Улаанбаатар',
        phone: '77001122',
      },
    ],
  });
  console.log('✅ Warehouses created');

  // 6. Categories
  const categories = [
    { name: 'Электроник', nameCn: '电子产品', slug: 'electronics', icon: '📱', isGlobal: true },
    { name: 'Хувцас', nameCn: '服装', slug: 'clothing', icon: '👕', isGlobal: true },
    { name: 'Гутал', nameCn: '鞋子', slug: 'shoes', icon: '👟', isGlobal: true },
    { name: 'Гоо сайхан', nameCn: '化妆品', slug: 'cosmetics', icon: '💄', isGlobal: true },
    { name: 'Хүнс', nameCn: '食品', slug: 'food', icon: '🍜', isGlobal: true },
    { name: 'Тавилга', nameCn: '家具', slug: 'furniture', icon: '🛋️', isGlobal: true },
    { name: 'Авто сэлбэг', nameCn: '汽车配件', slug: 'auto-parts', icon: '🔧', isGlobal: true },
    { name: 'Бусад', nameCn: '其他', slug: 'other', icon: '📦', isGlobal: true },
  ];
  await prisma.category.createMany({ data: categories });
  console.log('✅ Categories created');

  // 7. Pricing Rules
  await prisma.pricingRule.create({
    data: {
      companyId: company.id,
      name: 'Стандарт тариф',
      pricePerKg: 8500,
      isDefault: true,
    },
  });
  console.log('✅ Pricing rules created');

  // 8. Exchange Rate
  await prisma.exchangeRate.create({
    data: {
      fromCurrency: 'CNY',
      toCurrency: 'MNT',
      rate: 478.50,
      source: 'manual',
      effectiveAt: new Date(),
    },
  });
  console.log('✅ Exchange rate created');

  // 9. Ratings Summary (empty)
  await prisma.companyRatingsSummary.create({
    data: { companyId: company.id },
  });

  // 10. Cargo Admin
  const cargoAdminPwd = await bcrypt.hash('cargo123456', 12);
  await prisma.user.create({
    data: {
      phone: '88001122',
      firstName: 'Болд',
      password: cargoAdminPwd,
      role: 'CARGO_ADMIN',
      companyId: company.id,
      otpVerified: true,
    },
  });
  console.log('✅ Cargo admin created');

  // 11. Staff
  const staffPwd = await bcrypt.hash('staff123456', 12);
  await prisma.user.create({
    data: {
      phone: '88003344',
      firstName: 'Сүхээ',
      password: staffPwd,
      role: 'STAFF_CHINA',
      companyId: company.id,
      otpVerified: true,
    },
  });
  console.log('✅ Staff created');

  // 12. Demo Customer
  const customerPwd = await bcrypt.hash('customer123', 12);
  const customer = await prisma.user.create({
    data: {
      phone: '99887766',
      firstName: 'Бат-Эрдэнэ',
      password: customerPwd,
      role: 'CUSTOMER',
      otpVerified: true,
    },
  });

  await prisma.customerCompany.create({
    data: {
      userId: customer.id,
      companyId: company.id,
      customerCode: 'CGE-1001',
      isPrimary: true,
    },
  });
  console.log('✅ Demo customer created: CGE-1001');

  console.log('\n🎉 Seed completed!\n');
  console.log('Demo accounts:');
  console.log('  Super Admin:  99112233 / admin123456');
  console.log('  Cargo Admin:  88001122 / cargo123456');
  console.log('  Staff China:  88003344 / staff123456');
  console.log('  Customer:     99887766 / customer123');
  console.log('  Config pwd:   zamex_config_2025');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());

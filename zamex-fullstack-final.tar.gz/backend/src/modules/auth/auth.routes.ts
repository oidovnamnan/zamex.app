import { Router, Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { v4 as uuid } from 'uuid';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';
import { authenticate, JwtPayload } from '../../middleware/auth';

export const authRouter = Router();

// ═══ Validation Schemas ═══

const registerSchema = z.object({
  phone: z.string().min(8).max(15),
  firstName: z.string().min(1).max(50),
  lastName: z.string().max(50).optional(),
  password: z.string().min(6).max(100),
});

const loginSchema = z.object({
  phone: z.string().min(8).max(15),
  password: z.string().min(1),
});

const otpVerifySchema = z.object({
  phone: z.string().min(8).max(15),
  otp: z.string().length(4),
});

// ═══ Helpers ═══

function generateTokens(payload: JwtPayload) {
  const accessToken = jwt.sign(payload, process.env.JWT_SECRET!, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m',
  });
  const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET!, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
  return { accessToken, refreshToken };
}

function generateOtp(): string {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

// ═══ Routes ═══

// POST /api/auth/register
authRouter.post('/register', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = registerSchema.parse(req.body);

    const existing = await prisma.user.findUnique({ where: { phone: data.phone } });
    if (existing) {
      throw new AppError('Энэ утасны дугаараар бүртгэл үүссэн байна', 409);
    }

    const hashedPassword = await bcrypt.hash(data.password, 12);
    const otp = generateOtp();

    const user = await prisma.user.create({
      data: {
        phone: data.phone,
        firstName: data.firstName,
        lastName: data.lastName,
        password: hashedPassword,
        role: 'CUSTOMER',
        otpCode: otp,
        otpExpiresAt: new Date(Date.now() + 5 * 60 * 1000), // 5 min
      },
      select: { id: true, phone: true, firstName: true, role: true },
    });

    // TODO: Send OTP via SMS
    console.log(`📱 OTP for ${data.phone}: ${otp}`);

    res.status(201).json({
      success: true,
      message: 'Бүртгэл амжилттай. OTP код илгээлээ.',
      data: { userId: user.id, phone: user.phone },
    });
  } catch (e) { next(e); }
});

// POST /api/auth/otp/verify
authRouter.post('/otp/verify', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = otpVerifySchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { phone: data.phone } });
    if (!user) throw new AppError('Хэрэглэгч олдсонгүй', 404);
    if (user.otpVerified) throw new AppError('Аль хэдийн баталгаажсан', 400);
    if (!user.otpCode || !user.otpExpiresAt) throw new AppError('OTP код илгээгдээгүй', 400);
    if (new Date() > user.otpExpiresAt) throw new AppError('OTP код хугацаа дууссан', 400);
    if (user.otpCode !== data.otp) throw new AppError('OTP код буруу', 400);

    await prisma.user.update({
      where: { id: user.id },
      data: { otpVerified: true, otpCode: null, otpExpiresAt: null },
    });

    const payload: JwtPayload = { userId: user.id, role: user.role, companyId: user.companyId || undefined };
    const tokens = generateTokens(payload);

    await prisma.refreshToken.create({
      data: {
        token: tokens.refreshToken,
        userId: user.id,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    res.json({
      success: true,
      message: 'Баталгаажлаа',
      data: {
        user: { id: user.id, phone: user.phone, firstName: user.firstName, role: user.role },
        tokens,
      },
    });
  } catch (e) { next(e); }
});

// POST /api/auth/login
authRouter.post('/login', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { phone: data.phone } });
    if (!user) throw new AppError('Утас эсвэл нууц үг буруу', 401);
    if (!user.isActive) throw new AppError('Хэрэглэгч идэвхгүй байна', 403);

    const isMatch = await bcrypt.compare(data.password, user.password);
    if (!isMatch) throw new AppError('Утас эсвэл нууц үг буруу', 401);

    if (!user.otpVerified) {
      // Resend OTP
      const otp = generateOtp();
      await prisma.user.update({
        where: { id: user.id },
        data: { otpCode: otp, otpExpiresAt: new Date(Date.now() + 5 * 60 * 1000) },
      });
      console.log(`📱 OTP for ${data.phone}: ${otp}`);

      return res.json({
        success: true,
        message: 'OTP баталгаажуулалт шаардлагатай',
        data: { requireOtp: true, phone: user.phone },
      });
    }

    const payload: JwtPayload = { userId: user.id, role: user.role, companyId: user.companyId || undefined };
    const tokens = generateTokens(payload);

    await prisma.refreshToken.create({
      data: {
        token: tokens.refreshToken,
        userId: user.id,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    await prisma.user.update({ where: { id: user.id }, data: { lastLogin: new Date() } });

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          phone: user.phone,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          companyId: user.companyId,
        },
        tokens,
      },
    });
  } catch (e) { next(e); }
});

// POST /api/auth/refresh
authRouter.post('/refresh', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) throw new AppError('Refresh token шаардлагатай', 400);

    const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
    if (!stored) throw new AppError('Token хүчингүй', 401);
    if (new Date() > stored.expiresAt) {
      await prisma.refreshToken.delete({ where: { id: stored.id } });
      throw new AppError('Token хугацаа дууссан', 401);
    }

    const user = await prisma.user.findUnique({ where: { id: stored.userId } });
    if (!user || !user.isActive) throw new AppError('Хэрэглэгч олдсонгүй', 401);

    // Delete old, create new
    await prisma.refreshToken.delete({ where: { id: stored.id } });

    const payload: JwtPayload = { userId: user.id, role: user.role, companyId: user.companyId || undefined };
    const tokens = generateTokens(payload);

    await prisma.refreshToken.create({
      data: {
        token: tokens.refreshToken,
        userId: user.id,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    res.json({ success: true, data: { tokens } });
  } catch (e) { next(e); }
});

// POST /api/auth/logout
authRouter.post('/logout', authenticate, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
    }
    res.json({ success: true, message: 'Амжилттай гарлаа' });
  } catch (e) { next(e); }
});

// GET /api/auth/me
authRouter.get('/me', authenticate, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: {
        id: true, phone: true, firstName: true, lastName: true,
        role: true, avatarUrl: true, companyId: true,
        customerCompanies: {
          include: { company: { select: { id: true, name: true, codePrefix: true, logoUrl: true } } },
        },
      },
    });
    if (!user) throw new AppError('Хэрэглэгч олдсонгүй', 404);

    res.json({ success: true, data: { user } });
  } catch (e) { next(e); }
});

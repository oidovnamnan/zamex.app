import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';

export const settlementsRouter = Router();
settlementsRouter.use(authenticate);
settlementsRouter.use(authorize('CARGO_ADMIN', 'SUPER_ADMIN'));

// POST /api/settlements/generate - Generate weekly settlement for a company
settlementsRouter.post('/generate', authorize('SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { companyId, periodStart, periodEnd } = req.body;
    if (!companyId || !periodStart || !periodEnd) throw new AppError('companyId, periodStart, periodEnd шаардлагатай', 400);

    const start = new Date(periodStart);
    const end = new Date(periodEnd);

    // Get all platform fees in period
    const fees = await prisma.platformFee.findMany({
      where: {
        companyId,
        createdAt: { gte: start, lte: end },
      },
      include: { invoice: { select: { status: true } } },
    });

    const paidFees = fees.filter(f => f.invoice.status === 'PAID');

    const totalShippingRevenue = paidFees.reduce((s, f) => s + Number(f.shippingAmount), 0);
    const totalPlatformFees = paidFees.reduce((s, f) => s + Number(f.feeAmount), 0);
    const totalQpayFees = paidFees.reduce((s, f) => s + Number(f.qpayFee), 0);

    // Get refunds in period
    const refunds = await prisma.refundTransaction.findMany({
      where: {
        request: { companyId },
        createdAt: { gte: start, lte: end },
        chargedTo: { in: ['CARGO_CHINA', 'CARGO_TRANSIT', 'CARGO_MONGOLIA'] },
      },
    });
    const totalRefunds = refunds.reduce((s, r) => s + Number(r.shippingRefund) + Number(r.compensation), 0);

    const netAmount = totalShippingRevenue - totalPlatformFees - totalQpayFees - totalRefunds;

    const settlement = await prisma.settlement.create({
      data: {
        companyId,
        periodStart: start,
        periodEnd: end,
        totalShippingRevenue,
        totalPlatformFees,
        totalQpayFees,
        totalRefunds,
        netAmount,
        status: 'PENDING',
      },
    });

    res.status(201).json({ success: true, data: { settlement } });
  } catch (e) { next(e); }
});

// PATCH /api/settlements/:id/transfer - Mark as transferred
settlementsRouter.patch('/:id/transfer', authorize('SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { bankName, bankAccount, transferReference } = req.body;
    const updated = await prisma.settlement.update({
      where: { id: req.params.id },
      data: {
        status: 'COMPLETED',
        bankName,
        bankAccount,
        transferReference,
        transferredAt: new Date(),
      },
    });
    res.json({ success: true, data: { settlement: updated } });
  } catch (e) { next(e); }
});

// GET /api/settlements
settlementsRouter.get('/', async (req, res, next) => {
  try {
    const companyId = req.user!.role === 'SUPER_ADMIN' ? (req.query.companyId as string) : req.user!.companyId;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const where: any = {};
    if (companyId) where.companyId = companyId;

    const [settlements, total] = await Promise.all([
      prisma.settlement.findMany({
        where,
        include: { company: { select: { name: true } } },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.settlement.count({ where }),
    ]);

    res.json({ success: true, data: { settlements, total, page, limit } });
  } catch (e) { next(e); }
});

import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';
import { z } from 'zod';

export const batchesRouter = Router();
batchesRouter.use(authenticate);
batchesRouter.use(authorize('STAFF_CHINA', 'STAFF_MONGOLIA', 'DRIVER', 'CARGO_ADMIN', 'SUPER_ADMIN'));

// POST /api/batches - Create new batch
batchesRouter.post('/', async (req, res, next) => {
  try {
    const { companyId, vehicleInfo } = req.body;
    if (!companyId) throw new AppError('companyId шаардлагатай', 400);

    const count = await prisma.batch.count({ where: { companyId } });
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const batchCode = `B-${today}-${String(count + 1).padStart(3, '0')}`;

    const batch = await prisma.batch.create({
      data: { companyId, batchCode, vehicleInfo },
    });

    res.status(201).json({ success: true, data: { batch } });
  } catch (e) { next(e); }
});

// POST /api/batches/:id/packages - Add packages to batch
batchesRouter.post('/:id/packages', async (req, res, next) => {
  try {
    const { packageIds } = req.body;
    if (!Array.isArray(packageIds) || !packageIds.length) {
      throw new AppError('packageIds жагсаалт шаардлагатай', 400);
    }

    const batch = await prisma.batch.findUnique({ where: { id: req.params.id } });
    if (!batch) throw new AppError('Batch олдсонгүй', 404);
    if (batch.status !== 'OPEN') throw new AppError('Batch хаагдсан байна', 400);

    const packages = await prisma.package.findMany({
      where: { id: { in: packageIds }, batchId: null },
    });

    if (packages.length !== packageIds.length) {
      throw new AppError('Зарим бараа олдсонгүй эсвэл аль хэдийн batch-д орсон', 400);
    }

    await prisma.package.updateMany({
      where: { id: { in: packageIds } },
      data: { batchId: batch.id, status: 'BATCHED' },
    });

    const totalWeight = packages.reduce((sum, p) => sum + Number(p.weightKg || 0), 0);

    const updated = await prisma.batch.update({
      where: { id: batch.id },
      data: {
        totalPackages: { increment: packages.length },
        totalWeight: { increment: totalWeight },
      },
    });

    res.json({
      success: true,
      message: `${packages.length} бараа нэмэгдлээ`,
      data: { batch: updated },
    });
  } catch (e) { next(e); }
});

// PATCH /api/batches/:id/close - Close batch (no more packages)
batchesRouter.patch('/:id/close', async (req, res, next) => {
  try {
    const batch = await prisma.batch.findUnique({ where: { id: req.params.id } });
    if (!batch) throw new AppError('Batch олдсонгүй', 404);
    if (batch.status !== 'OPEN') throw new AppError('Batch аль хэдийн хаагдсан', 400);
    if (batch.totalPackages === 0) throw new AppError('Batch хоосон байна', 400);

    const updated = await prisma.batch.update({
      where: { id: req.params.id },
      data: { status: 'CLOSED' },
    });

    res.json({ success: true, data: { batch: updated } });
  } catch (e) { next(e); }
});

// PATCH /api/batches/:id/depart - Batch departs
batchesRouter.patch('/:id/depart', async (req, res, next) => {
  try {
    const { driverId } = req.body;

    const batch = await prisma.batch.findUnique({ where: { id: req.params.id } });
    if (!batch) throw new AppError('Batch олдсонгүй', 404);
    if (!['CLOSED', 'LOADING'].includes(batch.status)) {
      throw new AppError('Batch хаагдсан байх ёстой', 400);
    }

    const updated = await prisma.batch.update({
      where: { id: req.params.id },
      data: {
        status: 'DEPARTED',
        driverId,
        departedAt: new Date(),
      },
    });

    // Update all packages in batch
    await prisma.package.updateMany({
      where: { batchId: batch.id },
      data: { status: 'DEPARTED', departedAt: new Date() },
    });

    res.json({ success: true, data: { batch: updated } });
  } catch (e) { next(e); }
});

// PATCH /api/batches/:id/arrive - Batch arrives at UB
batchesRouter.patch('/:id/arrive', async (req, res, next) => {
  try {
    const batch = await prisma.batch.findUnique({ where: { id: req.params.id } });
    if (!batch) throw new AppError('Batch олдсонгүй', 404);

    const updated = await prisma.batch.update({
      where: { id: req.params.id },
      data: { status: 'ARRIVED', arrivedAt: new Date() },
    });

    await prisma.package.updateMany({
      where: { batchId: batch.id },
      data: { status: 'ARRIVED_MN', arrivedMnAt: new Date() },
    });

    res.json({ success: true, data: { batch: updated } });
  } catch (e) { next(e); }
});

// POST /api/batches/:id/gps - Record GPS location
batchesRouter.post('/:id/gps', async (req, res, next) => {
  try {
    const { latitude, longitude, speed, heading } = req.body;
    if (!latitude || !longitude) throw new AppError('Координат шаардлагатай', 400);

    const gps = await prisma.gpsTracking.create({
      data: { batchId: req.params.id, latitude, longitude, speed, heading },
    });

    res.json({ success: true, data: { gps } });
  } catch (e) { next(e); }
});

// GET /api/batches/:id/gps - Get GPS history
batchesRouter.get('/:id/gps', async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit as string) || 100;
    const points = await prisma.gpsTracking.findMany({
      where: { batchId: req.params.id },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    res.json({ success: true, data: { points } });
  } catch (e) { next(e); }
});

// GET /api/batches
batchesRouter.get('/', async (req, res, next) => {
  try {
    const companyId = req.user!.companyId || (req.query.companyId as string);
    const status = req.query.status as string;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const where: any = {};
    if (companyId) where.companyId = companyId;
    if (status) where.status = status;

    const [batches, total] = await Promise.all([
      prisma.batch.findMany({
        where,
        include: { _count: { select: { packages: true } } },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.batch.count({ where }),
    ]);

    res.json({ success: true, data: { batches, total, page, limit } });
  } catch (e) { next(e); }
});

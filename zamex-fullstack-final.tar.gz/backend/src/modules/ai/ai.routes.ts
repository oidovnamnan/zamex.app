import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';

export const aiRouter = Router();
aiRouter.use(authenticate);

// POST /api/ai/chat - AI chatbot
aiRouter.post('/chat', async (req, res, next) => {
  try {
    const { message, conversationId } = req.body;
    if (!message) throw new AppError('Мессеж оруулна уу', 400);

    const settings = await prisma.platformSettings.findFirst();
    if (!settings?.aiEnabled) throw new AppError('AI идэвхгүй', 400);

    // Get user context
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      include: {
        customerCompanies: { include: { company: true } },
        orders: { take: 5, orderBy: { createdAt: 'desc' }, include: { package: true } },
      },
    });

    const systemPrompt = `Та zamex.app карго платформын AI туслах боллоо. Монгол хэлээр хариулна.
Хэрэглэгчийн мэдээлэл:
- Нэр: ${user?.firstName}
- Утас: ${user?.phone}
- Каргонууд: ${user?.customerCompanies?.map(cc => `${cc.company.name} (${cc.customerCode})`).join(', ') || 'Бүртгүүлээгүй'}
- Сүүлийн захиалгууд: ${user?.orders?.map(o => `${o.orderCode}: ${o.status}`).join(', ') || 'Байхгүй'}

Чиглүүлэх чадвар:
- Захиалга хэрхэн үүсгэх
- Бараа хаана байгаа
- Даатгалын мэдээлэл
- Буцаалтын процесс
- Тээврийн зардал тооцох
- Каргоны үнэлгээ`;

    // In production, call OpenAI API
    // For now, return context-aware response
    let aiResponse = '';

    if (message.includes('хаана') || message.includes('бараа')) {
      const activeOrders = user?.orders?.filter(o => o.package && !['DELIVERED'].includes(o.package.status));
      if (activeOrders?.length) {
        aiResponse = `Таны идэвхтэй захиалгууд:\n${activeOrders.map(o =>
          `📦 ${o.orderCode}: ${o.package?.status === 'DEPARTED' ? 'Замд байна' : o.package?.status === 'ARRIVED_MN' ? 'УБ-д ирсэн' : o.package?.status || 'Хүлээгдэж буй'}`
        ).join('\n')}`;
      } else {
        aiResponse = 'Одоогоор идэвхтэй захиалга байхгүй байна. Шинэ захиалга үүсгэхийг хүсвэл "Захиалга" хэсэг рүү орно уу.';
      }
    } else if (message.includes('даатгал') || message.includes('insurance')) {
      aiResponse = `zamex.app-д 3 түвшний даатгал бий:
🟢 Энгийн (3%): 50% нөхнө, ₮500K хүртэл
🔵 Стандарт (5%): 80% нөхнө, ₮2M хүртэл ⭐
🟡 Премиум (8%): 100% нөхнө, ₮10M хүртэл

Захиалга үүсгэхэд даатгал сонгох боломжтой.`;
    } else if (message.includes('буцаалт') || message.includes('гэмтсэн')) {
      aiResponse = `Буцаалт нээхийн тулд:
1. Захиалгын дэлгэрэнгүй хэсэгт орно
2. "Буцаалт нээх" товч дарна
3. Асуудлын төрлөө сонгоно
4. Зураг оруулна
5. AI автоматаар хариуцагчийг тодорхойлно

Бараа авснаас хойш 7 хоногийн дотор буцаалт нээх боломжтой.`;
    } else if (message.includes('зардал') || message.includes('үнэ') || message.includes('тариф')) {
      const companies = user?.customerCompanies;
      if (companies?.length) {
        aiResponse = `Таны бүртгэлтэй каргонуудын тариф мэдээлэл тус бүрийн хуудаснаас харна уу. Ерөнхийдөө жингээр тооцоолж, CBM (эзэлхүүн) ихтэй бол эзэлхүүнээр тооцно.`;
      } else {
        aiResponse = 'Эхлээд каргод бүртгүүлнэ үү. "Карго" хэсэгт рейтинг, тариф мэдээлэл ил харагдана.';
      }
    } else {
      aiResponse = `Сайн байна уу, ${user?.firstName}! Би zamex.app-ын AI туслах. Надад дараах зүйлсийн талаар асуух боломжтой:

📦 Барааны байршил
🛡️ Даатгалын мэдээлэл
↩️ Буцаалтын процесс
💰 Тээврийн зардал
⭐ Каргоны үнэлгээ

Юу асуухыг хүсч байна?`;
    }

    // Log AI usage
    await prisma.aiUsageLog.create({
      data: {
        companyId: req.user!.companyId,
        service: 'chatbot',
        model: 'context-response',
        tokensIn: message.length,
        tokensOut: aiResponse.length,
        costUsd: 0,
        endpoint: '/ai/chat',
      },
    });

    res.json({
      success: true,
      data: { response: aiResponse, conversationId: conversationId || `conv_${Date.now()}` },
    });
  } catch (e) { next(e); }
});

// POST /api/ai/translate - Chinese ↔ Mongolian translation
aiRouter.post('/translate', async (req, res, next) => {
  try {
    const { text, from, to } = req.body;
    if (!text) throw new AppError('Текст оруулна уу', 400);

    // In production, call OpenAI API with GPT-4o
    // Placeholder response
    const translation = from === 'cn' ? `[Орчуулга MN]: ${text}` : `[翻译 CN]: ${text}`;

    await prisma.aiUsageLog.create({
      data: {
        service: 'translation',
        model: 'gpt-4o',
        tokensIn: text.length,
        tokensOut: translation.length,
        costUsd: 0.001,
        endpoint: '/ai/translate',
      },
    });

    res.json({ success: true, data: { translation, from, to } });
  } catch (e) { next(e); }
});

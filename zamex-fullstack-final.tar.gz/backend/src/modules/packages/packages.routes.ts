import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';
import { z } from 'zod';

export const packagesRouter = Router();
packagesRouter.use(authenticate);

// ═══ Validation ═══

const receivePackageSchema = z.object({
  companyId: z.string().uuid(),
  orderCode: z.string().optional(),
  trackingNumber: z.string().optional(),
  weightKg: z.number().positive().optional(),
  lengthCm: z.number().positive().optional(),
  widthCm: z.number().positive().optional(),
  heightCm: z.number().positive().optional(),
  categoryId: z.string().uuid().optional(),
  labelPhotoUrl: z.string().optional(),
  packagePhotos: z.array(z.string()).default([]),
  shelfLocation: z.string().optional(),
  warehouseId: z.string().uuid().optional(),
});

// ═══ Routes ═══

// POST /api/packages/receive - Staff receives package at China warehouse
packagesRouter.post('/receive', authorize('STAFF_CHINA', 'CARGO_ADMIN', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const data = receivePackageSchema.parse(req.body);

    // Try to match with existing order
    let matchedOrder = null;

    // Match by order code
    if (data.orderCode) {
      matchedOrder = await prisma.order.findUnique({
        where: { orderCode: data.orderCode },
        include: { customer: { select: { id: true, firstName: true, phone: true } } },
      });
    }

    // Match by tracking number
    if (!matchedOrder && data.trackingNumber) {
      matchedOrder = await prisma.order.findFirst({
        where: {
          companyId: data.companyId,
          trackingNumber: data.trackingNumber,
          status: { in: ['PENDING', 'PRE_ANNOUNCED'] },
        },
        include: { customer: { select: { id: true, firstName: true, phone: true } } },
      });
    }

    // Calculate CBM
    let cbm = null;
    if (data.lengthCm && data.widthCm && data.heightCm) {
      cbm = (data.lengthCm * data.widthCm * data.heightCm) / 1000000;
    }

    // Calculate shipping cost
    let shippingCost = null;
    if (data.weightKg) {
      const pricingRule = await prisma.pricingRule.findFirst({
        where: {
          companyId: data.companyId,
          isActive: true,
          ...(data.categoryId ? { categoryId: data.categoryId } : { isDefault: true }),
        },
      });
      if (pricingRule) {
        const weightCost = data.weightKg * Number(pricingRule.pricePerKg);
        const cbmCost = cbm && pricingRule.pricePerCbm ? cbm * Number(pricingRule.pricePerCbm) : 0;
        shippingCost = Math.max(weightCost, cbmCost);
      }
    }

    // Create package
    const pkg = await prisma.package.create({
      data: {
        companyId: data.companyId,
        customerId: matchedOrder?.customerId,
        trackingNumber: data.trackingNumber,
        weightKg: data.weightKg,
        lengthCm: data.lengthCm,
        widthCm: data.widthCm,
        heightCm: data.heightCm,
        cbm,
        categoryId: data.categoryId,
        labelPhotoUrl: data.labelPhotoUrl,
        packagePhotos: data.packagePhotos,
        shelfLocation: data.shelfLocation,
        warehouseId: data.warehouseId,
        shippingCost,
        status: data.weightKg ? 'MEASURED' : 'RECEIVED_IN_CHINA',
        receivedAt: new Date(),
        measuredAt: data.weightKg ? new Date() : null,
        registeredById: req.user!.userId,
      },
    });

    // Link to order if matched
    if (matchedOrder) {
      await prisma.order.update({
        where: { id: matchedOrder.id },
        data: { packageId: pkg.id, status: 'MATCHED', matchedAt: new Date() },
      });
    }

    // If not matched, create unidentified package
    let unidentified = null;
    if (!matchedOrder) {
      const count = await prisma.unidentifiedPackage.count({ where: { companyId: data.companyId } });
      const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const tempCode = `UNID-${today}-${String(count + 1).padStart(3, '0')}`;
      const settings = await prisma.platformSettings.findFirst();
      const storageDays = settings?.unidentifiedStorageDays || 90;

      unidentified = await prisma.unidentifiedPackage.create({
        data: {
          companyId: data.companyId,
          tempCode,
          partialTracking: data.trackingNumber,
          labelPhotoUrl: data.labelPhotoUrl || '',
          packagePhotos: data.packagePhotos,
          weightKg: data.weightKg,
          shelfLocation: data.shelfLocation,
          registeredBy: req.user!.userId,
          expiresAt: new Date(Date.now() + storageDays * 24 * 60 * 60 * 1000),
        },
      });
    }

    res.status(201).json({
      success: true,
      message: matchedOrder ? `Бараа бүртгэгдлээ → ${matchedOrder.orderCode}` : 'Эзэнгүй бараа бүртгэгдлээ',
      data: {
        package: {
          id: pkg.id,
          status: pkg.status,
          shippingCost,
          matched: !!matchedOrder,
          orderCode: matchedOrder?.orderCode,
          customerName: matchedOrder?.customer?.firstName,
        },
        unidentified: unidentified ? { id: unidentified.id, tempCode: unidentified.tempCode } : null,
      },
    });
  } catch (e) { next(e); }
});

// GET /api/packages - Company packages list
packagesRouter.get('/', authorize('STAFF_CHINA', 'STAFF_MONGOLIA', 'CARGO_ADMIN', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const companyId = req.user!.companyId || (req.query.companyId as string);
    const status = req.query.status as string;
    const batchId = req.query.batchId as string;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;

    const where: any = {};
    if (companyId) where.companyId = companyId;
    if (status) where.status = status;
    if (batchId) where.batchId = batchId;

    const [packages, total] = await Promise.all([
      prisma.package.findMany({
        where,
        include: {
          order: { select: { orderCode: true, productTitle: true } },
          category: { select: { name: true } },
          batch: { select: { batchCode: true, status: true } },
        },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.package.count({ where }),
    ]);

    res.json({ success: true, data: { packages, total, page, limit } });
  } catch (e) { next(e); }
});

// PATCH /api/packages/:id/measure - Update measurement
packagesRouter.patch('/:id/measure', authorize('STAFF_CHINA', 'CARGO_ADMIN', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { weightKg, lengthCm, widthCm, heightCm, categoryId } = req.body;

    let cbm = null;
    if (lengthCm && widthCm && heightCm) {
      cbm = (lengthCm * widthCm * heightCm) / 1000000;
    }

    // Recalculate shipping cost
    const pkg = await prisma.package.findUnique({ where: { id: req.params.id } });
    if (!pkg) throw new AppError('Бараа олдсонгүй', 404);

    let shippingCost = null;
    if (weightKg) {
      const pricingRule = await prisma.pricingRule.findFirst({
        where: {
          companyId: pkg.companyId,
          isActive: true,
          ...(categoryId ? { categoryId } : { isDefault: true }),
        },
      });
      if (pricingRule) {
        const wCost = weightKg * Number(pricingRule.pricePerKg);
        const cCost = cbm && pricingRule.pricePerCbm ? cbm * Number(pricingRule.pricePerCbm) : 0;
        shippingCost = Math.max(wCost, cCost);
      }
    }

    const updated = await prisma.package.update({
      where: { id: req.params.id },
      data: {
        weightKg,
        lengthCm,
        widthCm,
        heightCm,
        cbm,
        categoryId,
        shippingCost,
        status: 'MEASURED',
        measuredAt: new Date(),
      },
    });

    res.json({ success: true, data: { package: updated } });
  } catch (e) { next(e); }
});

// PATCH /api/packages/:id/status - Update status
packagesRouter.patch('/:id/status', authorize('STAFF_CHINA', 'STAFF_MONGOLIA', 'DRIVER', 'CARGO_ADMIN', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { status, shelfLocation, warehouseId } = req.body;
    if (!status) throw new AppError('Төлөв оруулна уу', 400);

    const updateData: any = { status };

    if (status === 'DEPARTED') updateData.departedAt = new Date();
    if (status === 'ARRIVED_MN') updateData.arrivedMnAt = new Date();
    if (status === 'DELIVERED') updateData.deliveredAt = new Date();
    if (shelfLocation) updateData.shelfLocation = shelfLocation;
    if (warehouseId) updateData.warehouseId = warehouseId;

    const updated = await prisma.package.update({
      where: { id: req.params.id },
      data: updateData,
    });

    res.json({ success: true, data: { package: updated } });
  } catch (e) { next(e); }
});

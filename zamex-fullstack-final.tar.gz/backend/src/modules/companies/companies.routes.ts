import { Router } from 'express';
import { authenticate, authorize, authorizeCompany } from '../../middleware/auth';
import { prisma } from '../../server';
import { AppError } from '../../middleware/errorHandler';
import { z } from 'zod';

export const companiesRouter = Router();

// GET /api/companies - Public: карго жагсаалт (рейтингээр эрэмбэлсэн)
companiesRouter.get('/', async (req, res, next) => {
  try {
    const companies = await prisma.company.findMany({
      where: { isActive: true },
      select: {
        id: true, name: true, nameEn: true, slug: true, logoUrl: true,
        phone: true, description: true, codePrefix: true,
        ratingsSummary: {
          select: {
            averageRating: true, totalRatings: true, avgSpeed: true,
            avgSafety: true, avgService: true, avgPrice: true,
            totalDelivered: true, avgDeliveryDays: true, damageRate: true,
            returnRate: true, rankScore: true, rankPosition: true,
          },
        },
        pricingRules: {
          where: { isDefault: true, isActive: true },
          select: { pricePerKg: true },
          take: 1,
        },
      },
      orderBy: { ratingsSummary: { rankScore: 'desc' } },
    });

    res.json({ success: true, data: { companies } });
  } catch (e) { next(e); }
});

// POST /api/companies/:companyId/join - Customer joins a cargo company
companiesRouter.post('/:companyId/join', authenticate, authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const { companyId } = req.params;
    const userId = req.user!.userId;

    const company = await prisma.company.findUnique({ where: { id: companyId } });
    if (!company || !company.isActive) throw new AppError('Карго компани олдсонгүй', 404);

    // Check if already joined
    const existing = await prisma.customerCompany.findUnique({
      where: { userId_companyId: { userId, companyId } },
    });
    if (existing) throw new AppError('Энэ каргод аль хэдийн бүртгүүлсэн', 409);

    // Generate customer code
    const lastCustomer = await prisma.customerCompany.findFirst({
      where: { companyId },
      orderBy: { joinedAt: 'desc' },
    });
    let nextCode = 1001;
    if (lastCustomer) {
      const lastNum = parseInt(lastCustomer.customerCode.split('-')[1] || '1000');
      nextCode = lastNum + 1;
    }
    const customerCode = `${company.codePrefix}-${nextCode}`;

    const isPrimary = !(await prisma.customerCompany.findFirst({ where: { userId } }));

    const customerCompany = await prisma.customerCompany.create({
      data: { userId, companyId, customerCode, isPrimary },
      include: {
        company: { select: { id: true, name: true, codePrefix: true, logoUrl: true } },
      },
    });

    res.status(201).json({
      success: true,
      message: `${company.name} каргод амжилттай бүртгүүллээ`,
      data: { customerCode, company: customerCompany.company },
    });
  } catch (e) { next(e); }
});

// GET /api/companies/:companyId/ratings - Company ratings
companiesRouter.get('/:companyId/ratings', async (req, res, next) => {
  try {
    const { companyId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const [ratings, summary] = await Promise.all([
      prisma.rating.findMany({
        where: { companyId, isVisible: true },
        select: {
          id: true, overallRating: true, speedRating: true, safetyRating: true,
          serviceRating: true, comment: true, tags: true,
          companyResponse: true, companyRespondedAt: true,
          hadReturnRequest: true, createdAt: true,
          customer: { select: { firstName: true } },
        },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.companyRatingsSummary.findUnique({ where: { companyId } }),
    ]);

    res.json({ success: true, data: { ratings, summary, page, limit } });
  } catch (e) { next(e); }
});

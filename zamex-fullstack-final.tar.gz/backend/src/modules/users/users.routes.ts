import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth';
import { prisma } from '../../server';

export const usersRouter = Router();

usersRouter.use(authenticate);

// GET /api/users - Super Admin: бүх хэрэглэгч
usersRouter.get('/', authorize('SUPER_ADMIN'), async (req, res, next) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const role = req.query.role as string;

    const where: any = {};
    if (role) where.role = role;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true, phone: true, firstName: true, lastName: true,
          role: true, isActive: true, lastLogin: true, createdAt: true,
          companyId: true,
        },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.user.count({ where }),
    ]);

    res.json({ success: true, data: { users, total, page, limit } });
  } catch (e) { next(e); }
});

import { create } from 'zustand';
import { api } from './api';

interface User {
  id: string;
  phone: string;
  firstName: string;
  lastName?: string;
  role: string;
  companyId?: string;
  avatarUrl?: string;
  customerCompanies?: any[];
}

interface AuthStore {
  user: User | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  login: (phone: string, password: string) => Promise<any>;
  register: (phone: string, firstName: string, password: string) => Promise<any>;
  verifyOtp: (phone: string, otp: string) => Promise<any>;
  logout: () => void;
  fetchMe: () => Promise<void>;
}

export const useAuth = create<AuthStore>((set) => ({
  user: null,
  loading: true,

  setUser: (user) => set({ user, loading: false }),

  login: async (phone, password) => {
    const { data } = await api.post('/auth/login', { phone, password });
    if (data.data.tokens) {
      localStorage.setItem('zamex_token', data.data.tokens.accessToken);
      localStorage.setItem('zamex_refresh', data.data.tokens.refreshToken);
      set({ user: data.data.user, loading: false });
    }
    return data;
  },

  register: async (phone, firstName, password) => {
    const { data } = await api.post('/auth/register', { phone, firstName, password });
    return data;
  },

  verifyOtp: async (phone, otp) => {
    const { data } = await api.post('/auth/otp/verify', { phone, otp });
    if (data.data.tokens) {
      localStorage.setItem('zamex_token', data.data.tokens.accessToken);
      localStorage.setItem('zamex_refresh', data.data.tokens.refreshToken);
      set({ user: data.data.user, loading: false });
    }
    return data;
  },

  logout: () => {
    const refresh = localStorage.getItem('zamex_refresh');
    if (refresh) api.post('/auth/logout', { refreshToken: refresh }).catch(() => {});
    localStorage.removeItem('zamex_token');
    localStorage.removeItem('zamex_refresh');
    set({ user: null, loading: false });
  },

  fetchMe: async () => {
    try {
      const token = localStorage.getItem('zamex_token');
      if (!token) { set({ user: null, loading: false }); return; }
      const { data } = await api.get('/auth/me');
      set({ user: data.data.user, loading: false });
    } catch {
      set({ user: null, loading: false });
    }
  },
}));

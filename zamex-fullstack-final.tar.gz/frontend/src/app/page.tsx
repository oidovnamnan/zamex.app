'use client';

import Link from 'next/link';
import { Package, Shield, Star, TrendingUp, Truck, Zap } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-surface-100">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-zamex-600 flex items-center justify-center">
              <Package className="w-4.5 h-4.5 text-white" />
            </div>
            <span className="text-lg font-bold text-surface-900">zamex</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth" className="btn-ghost btn-sm">Нэвтрэх</Link>
            <Link href="/auth?mode=register" className="btn-primary btn-sm">Бүртгүүлэх</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-24">
        <div className="max-w-2xl">
          <div className="badge-blue mb-5">
            <Zap className="w-3 h-3" /> Шинэ платформ
          </div>
          <h1 className="text-5xl font-bold text-surface-900 tracking-tight leading-[1.1] mb-5">
            Карго тээврийг
            <br />
            <span className="text-zamex-600">ухаалаг</span> болгоё
          </h1>
          <p className="text-lg text-surface-500 leading-relaxed mb-8 max-w-lg">
            Хятад-Монгол карго тээврийн бүрэн дижитал платформ.
            Захиалга, хяналт, төлбөр, даатгал — бүгд нэг дор.
          </p>
          <div className="flex gap-3">
            <Link href="/auth?mode=register" className="btn-primary btn-lg">
              Үнэгүй эхлэх
            </Link>
            <Link href="/companies" className="btn-secondary btn-lg">
              Карго хайх
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-surface-100 bg-surface-50/50">
        <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: '15+', label: 'Карго компани' },
            { value: '5,000+', label: 'Захиалагч' },
            { value: '99.2%', label: 'Хүргэлтийн амжилт' },
            { value: '7 хоног', label: 'Дундаж хүргэлт' },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-3xl font-bold text-surface-900">{s.value}</div>
              <div className="text-sm text-surface-500 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-2xl font-bold text-surface-900 mb-12 text-center">
          Яагаад zamex.app?
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: <Package className="w-5 h-5" />,
              title: '3 алхамаар захиалга',
              desc: 'Карго сонгох → Захиалга үүсгэх → Хаяг хуулах. Дараасгүй, хялбар.',
              color: 'bg-blue-50 text-blue-600',
            },
            {
              icon: <Truck className="w-5 h-5" />,
              title: 'Бодит цагийн хяналт',
              desc: 'GPS байршил, бараа хаана байгааг бодит цагаар хянана. Push мэдэгдэл.',
              color: 'bg-emerald-50 text-emerald-600',
            },
            {
              icon: <Shield className="w-5 h-5" />,
              title: 'Даатгал & Буцаалт',
              desc: '3 түвшний даатгал. Бараа эвдэрвэл автомат нөхөн олговор.',
              color: 'bg-violet-50 text-violet-600',
            },
            {
              icon: <Star className="w-5 h-5" />,
              title: 'Үнэлгээний систем',
              desc: 'Каргоны рейтинг ил харагдана. Өндөр үнэлгээтэй нь дээр.',
              color: 'bg-amber-50 text-amber-600',
            },
            {
              icon: <Zap className="w-5 h-5" />,
              title: 'AI ухаалаг систем',
              desc: 'Шошго автомат таних, барааны ангилал, чатбот, орчуулга.',
              color: 'bg-rose-50 text-rose-600',
            },
            {
              icon: <TrendingUp className="w-5 h-5" />,
              title: 'QPay төлбөр',
              desc: '1 товшилтоор төлнө. Бараа авах QR код автомат үүснэ.',
              color: 'bg-cyan-50 text-cyan-600',
            },
          ].map((f) => (
            <div key={f.title} className="card-hover p-6 group">
              <div className={`w-10 h-10 rounded-xl ${f.color} flex items-center justify-center mb-4`}>
                {f.icon}
              </div>
              <h3 className="text-base font-semibold text-surface-900 mb-1.5">{f.title}</h3>
              <p className="text-sm text-surface-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-6 pb-20">
        <div className="card bg-zamex-950 text-white p-12 text-center">
          <h2 className="text-2xl font-bold mb-3">Одоо эхлэх</h2>
          <p className="text-zamex-200 mb-6 max-w-md mx-auto">
            Бүртгүүлээд карго сонгоод бараагаа захиалаарай
          </p>
          <Link href="/auth?mode=register" className="btn btn-lg bg-white text-zamex-900 hover:bg-zamex-50">
            Үнэгүй бүртгүүлэх
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-surface-100 py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-sm text-surface-400">
          <span>© 2025 zamex.app</span>
          <span>Хятад-Монгол карго платформ</span>
        </div>
      </footer>
    </div>
  );
}

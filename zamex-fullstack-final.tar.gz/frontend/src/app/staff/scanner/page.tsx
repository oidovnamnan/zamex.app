'use client';

import { useState, useRef } from 'react';
import {
  Camera, Search, Package, Check, AlertTriangle, Scale,
  QrCode, Keyboard, ArrowLeft, X, Plus, Minus
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

type ScanMode = 'idle' | 'manual' | 'result';

export default function StaffScannerPage() {
  const { user } = useAuth();
  const companyId = user?.companyId;

  const [mode, setMode] = useState<ScanMode>('idle');
  const [searchQuery, setSearchQuery] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Manual entry
  const [orderCode, setOrderCode] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [weightKg, setWeightKg] = useState('');
  const [lengthCm, setLengthCm] = useState('');
  const [widthCm, setWidthCm] = useState('');
  const [heightCm, setHeightCm] = useState('');
  const [shelfLocation, setShelfLocation] = useState('');

  const handleReceive = async () => {
    if (!companyId) { toast.error('Компани тодорхойгүй'); return; }
    setLoading(true);
    try {
      const body: any = { companyId };
      if (orderCode) body.orderCode = orderCode;
      if (trackingNumber) body.trackingNumber = trackingNumber;
      if (weightKg) body.weightKg = parseFloat(weightKg);
      if (lengthCm) body.lengthCm = parseFloat(lengthCm);
      if (widthCm) body.widthCm = parseFloat(widthCm);
      if (heightCm) body.heightCm = parseFloat(heightCm);
      if (shelfLocation) body.shelfLocation = shelfLocation;

      const { data } = await api.post('/packages/receive', body);
      setResult(data.data);
      setMode('result');
      if (data.data.package.matched) {
        toast.success(`✅ ${data.data.package.orderCode} — бараа бүртгэгдлээ`);
      } else {
        toast('⚠️ Эзэнгүй бараа бүртгэгдлээ', { icon: '📦' });
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Алдаа гарлаа');
    }
    setLoading(false);
  };

  const resetForm = () => {
    setMode('idle');
    setResult(null);
    setOrderCode('');
    setTrackingNumber('');
    setWeightKg('');
    setLengthCm('');
    setWidthCm('');
    setHeightCm('');
    setShelfLocation('');
  };

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-zamex-950 text-white">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-zamex-300" />
            <span className="font-bold">Бараа хүлээн авах</span>
          </div>
          <span className="text-xs text-zamex-400">{user?.firstName} • Staff</span>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-4">

        {/* ═══ IDLE: Quick actions ═══ */}
        {mode === 'idle' && (
          <>
            {/* Camera scan button (placeholder) */}
            <button className="card-hover w-full p-8 flex flex-col items-center gap-3 text-center">
              <div className="w-16 h-16 rounded-2xl bg-zamex-50 text-zamex-600 flex items-center justify-center">
                <Camera className="w-8 h-8" />
              </div>
              <div>
                <div className="text-base font-semibold text-surface-900">Камераар скан</div>
                <div className="text-xs text-surface-400 mt-0.5">Шошго зураг авч AI-р таниулах</div>
              </div>
            </button>

            <div className="flex items-center gap-3 text-surface-300">
              <div className="flex-1 h-px bg-surface-200" />
              <span className="text-xs">эсвэл</span>
              <div className="flex-1 h-px bg-surface-200" />
            </div>

            {/* Manual entry */}
            <button onClick={() => setMode('manual')}
              className="card-hover w-full p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-surface-100 text-surface-600 flex items-center justify-center">
                <Keyboard className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-sm font-semibold text-surface-900">Гараар оруулах</div>
                <div className="text-xs text-surface-400">Код, tracking, жин оруулах</div>
              </div>
            </button>

            {/* Search */}
            <div className="card p-4">
              <label className="text-xs font-semibold text-surface-500 mb-2 block">Бараа хайх</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Код, tracking, утас..." className="input pl-10" />
              </div>
            </div>
          </>
        )}

        {/* ═══ MANUAL ENTRY ═══ */}
        {mode === 'manual' && (
          <div className="space-y-4">
            <button onClick={resetForm} className="btn-ghost btn-sm -ml-2">
              <ArrowLeft className="w-4 h-4" /> Буцах
            </button>

            <div className="card p-5 space-y-3.5">
              <h3 className="text-sm font-semibold text-surface-900">Барааны мэдээлэл</h3>

              <div>
                <label className="input-label">Захиалгын код (байвал)</label>
                <input value={orderCode} onChange={e => setOrderCode(e.target.value.toUpperCase())}
                  placeholder="CGE-1001-A7K2" className="input font-mono" />
              </div>

              <div>
                <label className="input-label">Tracking дугаар</label>
                <input value={trackingNumber} onChange={e => setTrackingNumber(e.target.value)}
                  placeholder="SF1234567890" className="input font-mono" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="input-label flex items-center gap-1">
                    <Scale className="w-3.5 h-3.5" /> Жин (кг)
                  </label>
                  <input type="number" step="0.01" value={weightKg}
                    onChange={e => setWeightKg(e.target.value)}
                    placeholder="0.00" className="input" />
                </div>
                <div>
                  <label className="input-label">Тавиур</label>
                  <input value={shelfLocation} onChange={e => setShelfLocation(e.target.value)}
                    placeholder="A-03" className="input font-mono" />
                </div>
              </div>

              <div>
                <label className="input-label">Овор (см)</label>
                <div className="grid grid-cols-3 gap-2">
                  <input type="number" value={lengthCm} onChange={e => setLengthCm(e.target.value)}
                    placeholder="Урт" className="input text-center" />
                  <input type="number" value={widthCm} onChange={e => setWidthCm(e.target.value)}
                    placeholder="Өргөн" className="input text-center" />
                  <input type="number" value={heightCm} onChange={e => setHeightCm(e.target.value)}
                    placeholder="Өндөр" className="input text-center" />
                </div>
              </div>

              {/* CBM display */}
              {lengthCm && widthCm && heightCm && (
                <div className="bg-surface-50 rounded-xl p-3 text-center">
                  <span className="text-xs text-surface-500">CBM: </span>
                  <span className="text-sm font-bold text-surface-900">
                    {(parseFloat(lengthCm) * parseFloat(widthCm) * parseFloat(heightCm) / 1000000).toFixed(4)} м³
                  </span>
                </div>
              )}
            </div>

            <button onClick={handleReceive} disabled={loading || (!orderCode && !trackingNumber)}
              className="btn-primary w-full btn-lg">
              {loading ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Бүртгэж байна...
                </span>
              ) : (
                <><Package className="w-5 h-5" /> Бараа бүртгэх</>
              )}
            </button>
          </div>
        )}

        {/* ═══ RESULT ═══ */}
        {mode === 'result' && result && (
          <div className="space-y-4">
            {/* Success/Warning Banner */}
            {result.package.matched ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center">
                <Check className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-emerald-900">Бараа бүртгэгдлээ</h3>
                <p className="text-sm text-emerald-700 mt-1">
                  Захиалга: <span className="font-mono font-bold">{result.package.orderCode}</span>
                </p>
                {result.package.customerName && (
                  <p className="text-sm text-emerald-600 mt-0.5">Харилцагч: {result.package.customerName}</p>
                )}
              </div>
            ) : (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 text-center">
                <AlertTriangle className="w-12 h-12 text-amber-600 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-amber-900">Эзэнгүй бараа</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Код: <span className="font-mono font-bold">{result.unidentified?.tempCode}</span>
                </p>
                <p className="text-xs text-amber-600 mt-2">
                  Захиалга олдсонгүй. Эзэнгүй бараа хэсэгт бүртгэгдлээ.
                </p>
              </div>
            )}

            {/* Package details */}
            {result.package.shippingCost && (
              <div className="card p-4 text-center">
                <span className="text-sm text-surface-500">Тээврийн зардал: </span>
                <span className="text-lg font-bold text-surface-900">
                  ₮{Number(result.package.shippingCost).toLocaleString()}
                </span>
              </div>
            )}

            <div className="flex gap-3">
              <button onClick={resetForm} className="btn-primary flex-1 btn-lg">
                <Package className="w-5 h-5" /> Дараагийн бараа
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

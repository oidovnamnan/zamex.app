'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, User, Phone, Building2, Shield, CreditCard,
  Bell, MessageCircle, LogOut, ChevronRight, Star, Package
} from 'lucide-react';
import { useAuth } from '@/lib/store';

export default function ProfilePage() {
  const router = useRouter();
  const { user, fetchMe, logout } = useAuth();

  useEffect(() => { fetchMe(); }, []);

  if (!user) return null;

  const companies = user.customerCompanies || [];

  return (
    <div className="min-h-screen bg-surface-50 pb-20">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="w-4.5 h-4.5" /></button>
          <h1 className="font-semibold text-surface-900">Профайл</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* User Info */}
        <div className="card p-5 flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-zamex-100 text-zamex-600 flex items-center justify-center text-xl font-bold">
            {user.firstName.charAt(0)}
          </div>
          <div>
            <h2 className="text-lg font-bold text-surface-900">{user.firstName} {user.lastName || ''}</h2>
            <div className="flex items-center gap-1 text-sm text-surface-400">
              <Phone className="w-3.5 h-3.5" /> {user.phone}
            </div>
            <span className="badge-blue mt-1">{user.role}</span>
          </div>
        </div>

        {/* My Cargos */}
        {companies.length > 0 && (
          <div className="card">
            <div className="p-4 border-b border-surface-100">
              <h3 className="text-sm font-semibold text-surface-900">Миний каргонууд</h3>
            </div>
            {companies.map((cc: any) => (
              <div key={cc.company.id} className="px-4 py-3 flex items-center justify-between border-b border-surface-50 last:border-0">
                <div className="flex items-center gap-3">
                  <Building2 className="w-5 h-5 text-surface-400" />
                  <div>
                    <div className="text-sm font-medium text-surface-900">{cc.company.name}</div>
                    <div className="text-xs text-surface-400 font-mono">Код: {cc.customerCode}</div>
                  </div>
                </div>
                {cc.isPrimary && <span className="badge-green">Үндсэн</span>}
              </div>
            ))}
          </div>
        )}

        {/* Quick Nav */}
        <div className="card divide-y divide-surface-100">
          {[
            { icon: Package, label: 'Захиалгууд', href: '/dashboard' },
            { icon: CreditCard, label: 'Нэхэмжлэх & Төлбөр', href: '/invoices' },
            { icon: Bell, label: 'Мэдэгдэл', href: '/notifications' },
            { icon: MessageCircle, label: 'AI Туслах', href: '/chat' },
            { icon: Star, label: 'Миний үнэлгээнүүд', href: '/ratings' },
          ].map(item => (
            <button key={item.label} onClick={() => router.push(item.href)}
              className="w-full px-4 py-3 flex items-center justify-between hover:bg-surface-50 transition">
              <div className="flex items-center gap-3">
                <item.icon className="w-5 h-5 text-surface-400" />
                <span className="text-sm text-surface-700">{item.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-surface-300" />
            </button>
          ))}
        </div>

        {/* Role-specific */}
        {['CARGO_ADMIN', 'SUPER_ADMIN'].includes(user.role) && (
          <div className="card divide-y divide-surface-100">
            <div className="px-4 py-2.5 text-xs font-semibold text-surface-400 uppercase">Удирдлага</div>
            {user.role === 'SUPER_ADMIN' && (
              <button onClick={() => router.push('/admin')} className="w-full px-4 py-3 flex items-center justify-between hover:bg-surface-50">
                <div className="flex items-center gap-3"><Shield className="w-5 h-5 text-red-400" /><span className="text-sm text-surface-700">Super Admin</span></div>
                <ChevronRight className="w-4 h-4 text-surface-300" />
              </button>
            )}
            {user.role === 'CARGO_ADMIN' && (
              <button onClick={() => router.push('/cargo')} className="w-full px-4 py-3 flex items-center justify-between hover:bg-surface-50">
                <div className="flex items-center gap-3"><Building2 className="w-5 h-5 text-zamex-500" /><span className="text-sm text-surface-700">Cargo Admin</span></div>
                <ChevronRight className="w-4 h-4 text-surface-300" />
              </button>
            )}
          </div>
        )}

        {/* Logout */}
        <button onClick={() => { logout(); router.push('/auth'); }}
          className="btn-secondary w-full text-red-600 border-red-200 hover:bg-red-50">
          <LogOut className="w-4 h-4" /> Гарах
        </button>
      </main>
    </div>
  );
}

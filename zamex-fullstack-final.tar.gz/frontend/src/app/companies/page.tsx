'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Star, Truck, Shield, Zap, Package, ChevronRight, Check } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

export default function CompaniesPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [companies, setCompanies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState<string | null>(null);

  useEffect(() => { loadCompanies(); }, []);

  const loadCompanies = async () => {
    try {
      const { data } = await api.get('/companies');
      setCompanies(data.data.companies);
    } catch { }
    setLoading(false);
  };

  const joinCompany = async (companyId: string) => {
    setJoining(companyId);
    try {
      const { data } = await api.post(`/companies/${companyId}/join`);
      toast.success(`${data.message}\nТаны код: ${data.data.customerCode}`);
      loadCompanies();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Алдаа гарлаа');
    }
    setJoining(null);
  };

  const isJoined = (companyId: string) =>
    user?.customerCompanies?.some((cc: any) => cc.company.id === companyId);

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2">
            <ArrowLeft className="w-4.5 h-4.5" />
          </button>
          <h1 className="font-semibold text-surface-900">Карго компаниуд</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5">
        <p className="text-sm text-surface-400 mb-4">
          Рейтинг, хурд, үнээр эрэмбэлсэн. Өндөр үнэлгээтэй нь дээр.
        </p>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-3 border-zamex-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="space-y-3">
            {companies.map((c, i) => {
              const r = c.ratingsSummary;
              const price = c.pricingRules?.[0]?.pricePerKg;
              const joined = isJoined(c.id);
              const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;

              return (
                <div key={c.id} className="card-hover p-4">
                  <div className="flex items-start gap-3">
                    {/* Rank */}
                    <div className="text-lg w-8 text-center flex-shrink-0 pt-0.5">
                      {medal}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-base font-semibold text-surface-900 truncate">{c.name}</h3>
                        {joined && (
                          <span className="badge-green"><Check className="w-3 h-3" /> Бүртгэлтэй</span>
                        )}
                      </div>

                      {/* Rating */}
                      <div className="flex items-center gap-3 mb-2.5">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                          <span className="text-sm font-semibold text-surface-900">
                            {r?.averageRating ? Number(r.averageRating).toFixed(1) : '—'}
                          </span>
                          <span className="text-xs text-surface-400">
                            ({r?.totalRatings || 0})
                          </span>
                        </div>
                        {price && (
                          <span className="text-sm font-medium text-surface-600">
                            ₮{Number(price).toLocaleString()}/кг
                          </span>
                        )}
                      </div>

                      {/* Sub-ratings */}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-surface-400">
                        {r?.avgSpeed > 0 && (
                          <span className="flex items-center gap-1">
                            <Zap className="w-3 h-3 text-amber-500" /> Хурд {Number(r.avgSpeed).toFixed(1)}
                          </span>
                        )}
                        {r?.avgSafety > 0 && (
                          <span className="flex items-center gap-1">
                            <Shield className="w-3 h-3 text-emerald-500" /> Аюулгүй {Number(r.avgSafety).toFixed(1)}
                          </span>
                        )}
                        {r?.avgDeliveryDays && (
                          <span className="flex items-center gap-1">
                            <Truck className="w-3 h-3 text-blue-500" /> ~{Math.round(Number(r.avgDeliveryDays))} хоног
                          </span>
                        )}
                        {r?.returnRate > 0 && Number(r.returnRate) > 3 && (
                          <span className="text-red-500">⚠ Буцаалт {Number(r.returnRate).toFixed(1)}%</span>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 mt-3">
                        {joined ? (
                          <button onClick={() => router.push(`/orders/new?companyId=${c.id}`)}
                            className="btn-primary btn-sm flex-1">
                            <Package className="w-3.5 h-3.5" /> Захиалга үүсгэх
                          </button>
                        ) : (
                          <button onClick={() => joinCompany(c.id)}
                            disabled={joining === c.id}
                            className="btn-primary btn-sm flex-1">
                            {joining === c.id ? 'Бүртгэж байна...' : 'Бүртгүүлэх'}
                          </button>
                        )}
                        <button onClick={() => router.push(`/companies/${c.id}`)}
                          className="btn-secondary btn-sm">
                          <Star className="w-3.5 h-3.5" /> Үнэлгээ
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!loading && companies.length === 0 && (
          <div className="card p-12 text-center">
            <Truck className="w-12 h-12 text-surface-200 mx-auto mb-4" />
            <p className="text-sm text-surface-400">Карго компани олдсонгүй</p>
          </div>
        )}
      </main>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Shield, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { api } from '@/lib/api';

export default function InsuranceFundPage() {
  const router = useRouter();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState<any[]>([]);

  useEffect(() => {
    // In production, fetch from dedicated endpoint
    // For now, we show placeholder
    setBalance(2450000);
    setTransactions([
      { id: '1', type: 'PREMIUM_IN', amount: 15000, balance: 2450000, description: 'Даатгалын хураамж: INV-20250209-0001', createdAt: new Date().toISOString() },
      { id: '2', type: 'PREMIUM_IN', amount: 28000, balance: 2435000, description: 'Даатгалын хураамж: INV-20250208-0012', createdAt: new Date(Date.now() - 86400000).toISOString() },
      { id: '3', type: 'PAYOUT_OUT', amount: -180000, balance: 2407000, description: 'Нөхөн олговор: RET-20250207-001', createdAt: new Date(Date.now() - 172800000).toISOString() },
    ]);
  }, []);

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="w-4.5 h-4.5" /></button>
          <h1 className="font-semibold text-surface-900">Даатгалын сан</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-5">
        <div className="card p-6 text-center bg-gradient-to-br from-zamex-50 to-blue-50">
          <Shield className="w-10 h-10 text-zamex-600 mx-auto mb-2" />
          <div className="text-xs text-surface-500 uppercase tracking-wide">Нийт үлдэгдэл</div>
          <div className="text-3xl font-bold text-surface-900 mt-1">₮{balance.toLocaleString()}</div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="card p-4 text-center">
            <TrendingUp className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
            <div className="text-xs text-surface-500">Энэ сар орсон</div>
            <div className="text-lg font-bold text-emerald-700">₮43,000</div>
          </div>
          <div className="card p-4 text-center">
            <TrendingDown className="w-5 h-5 text-red-500 mx-auto mb-1" />
            <div className="text-xs text-surface-500">Энэ сар гарсан</div>
            <div className="text-lg font-bold text-red-700">₮180,000</div>
          </div>
        </div>

        <div className="card">
          <div className="p-4 border-b border-surface-100">
            <h3 className="text-sm font-semibold text-surface-900">Гүйлгээний түүх</h3>
          </div>
          <div className="divide-y divide-surface-100">
            {transactions.map(t => (
              <div key={t.id} className="px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${t.amount > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                    {t.amount > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="text-sm text-surface-700">{t.description}</div>
                    <div className="text-xs text-surface-400">{new Date(t.createdAt).toLocaleDateString('mn-MN')}</div>
                  </div>
                </div>
                <div className={`text-sm font-bold ${t.amount > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {t.amount > 0 ? '+' : ''}₮{Math.abs(t.amount).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

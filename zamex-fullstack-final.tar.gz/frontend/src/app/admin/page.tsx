'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Package, Users, Building2, TrendingUp, Shield, AlertTriangle,
  Settings, BarChart3, DollarSign, Truck, Star, Lock, Eye, EyeOff,
  ChevronRight, RefreshCw, ToggleLeft, ToggleRight
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

export default function AdminDashboard() {
  const router = useRouter();
  const { user, loading, fetchMe } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [settings, setSettings] = useState<any>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [configPwd, setConfigPwd] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [editField, setEditField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchMe(); }, []);
  useEffect(() => {
    if (!loading && user) {
      if (user.role !== 'SUPER_ADMIN') { router.push('/dashboard'); return; }
      loadStats();
      loadSettings();
    }
  }, [user, loading]);

  const loadStats = async () => {
    try {
      const { data } = await api.get('/settings/dashboard');
      setStats(data.data);
    } catch {}
  };

  const loadSettings = async () => {
    try {
      const { data } = await api.get('/settings');
      setSettings(data.data.settings);
    } catch {}
  };

  const updateSetting = async (field: string, value: any) => {
    if (!configPwd) { toast.error('Тохиргооны нууц үг оруулна уу'); return; }
    setSaving(true);
    try {
      await api.put('/settings', { configPassword: configPwd, [field]: value });
      toast.success('Тохиргоо шинэчлэгдлээ');
      loadSettings();
      setEditField(null);
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Алдаа');
    }
    setSaving(false);
  };

  const toggleSetting = async (field: string, current: boolean) => {
    await updateSetting(field, !current);
  };

  if (loading || !user) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-3 border-zamex-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-zamex-950 text-white">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold">Super Admin</div>
              <div className="text-xs text-zamex-300">zamex.app</div>
            </div>
          </div>
          <button onClick={loadStats} className="btn-ghost btn-sm text-white/60 hover:text-white">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">

        {/* Stats Grid */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'Карго компани', value: stats.totalCompanies, icon: Building2, color: 'text-blue-600 bg-blue-50' },
              { label: 'Захиалагч', value: stats.totalCustomers?.toLocaleString(), icon: Users, color: 'text-violet-600 bg-violet-50' },
              { label: 'Энэ сарын захиалга', value: stats.monthlyOrders?.toLocaleString(), icon: Package, color: 'text-emerald-600 bg-emerald-50' },
              { label: 'Идэвхтэй бараа', value: stats.activePackages?.toLocaleString(), icon: Truck, color: 'text-amber-600 bg-amber-50' },
              { label: 'Сарын орлого', value: `₮${(Number(stats.monthlyRevenue) / 1000000).toFixed(1)}M`, icon: DollarSign, color: 'text-emerald-600 bg-emerald-50' },
              { label: 'zamex шимтгэл', value: `₮${(Number(stats.monthlyPlatformFees) / 1000).toFixed(0)}K`, icon: TrendingUp, color: 'text-zamex-600 bg-zamex-50' },
              { label: 'Хүлээгдэж буй буцаалт', value: stats.pendingReturns, icon: AlertTriangle, color: stats.pendingReturns > 0 ? 'text-red-600 bg-red-50' : 'text-surface-600 bg-surface-50' },
              { label: 'Эзэнгүй бараа', value: stats.unidentifiedCount, icon: Package, color: stats.unidentifiedCount > 0 ? 'text-amber-600 bg-amber-50' : 'text-surface-600 bg-surface-50' },
            ].map(s => (
              <div key={s.label} className="card p-4">
                <div className={`w-9 h-9 rounded-xl ${s.color} flex items-center justify-center mb-2.5`}>
                  <s.icon className="w-4.5 h-4.5" />
                </div>
                <div className="text-2xl font-bold text-surface-900">{s.value}</div>
                <div className="text-xs text-surface-400 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Quick Nav */}
        <div className="grid md:grid-cols-3 gap-3">
          {[
            { label: 'Карго компаниуд', desc: 'Удирдах, нэмэх', icon: Building2, href: '/admin/companies' },
            { label: 'Бүх захиалга', desc: 'Хайх, шүүх', icon: Package, href: '/admin/orders' },
            { label: 'Буцаалтууд', desc: 'Шалгах, шийдвэрлэх', icon: AlertTriangle, href: '/admin/returns' },
            { label: 'Даатгалын сан', desc: 'Үлдэгдэл, гүйлгээ', icon: Shield, href: '/admin/insurance' },
            { label: 'Settlement', desc: 'Каргод шилжүүлэг', icon: DollarSign, href: '/admin/settlements' },
            { label: 'Үнэлгээ & Рейтинг', desc: 'Каргоны эрэмбэ', icon: Star, href: '/admin/ratings' },
          ].map(item => (
            <button key={item.label} onClick={() => router.push(item.href)}
              className="card-hover p-4 text-left flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-surface-50 text-surface-600 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-surface-900">{item.label}</div>
                <div className="text-xs text-surface-400">{item.desc}</div>
              </div>
              <ChevronRight className="w-4 h-4 text-surface-300 flex-shrink-0" />
            </button>
          ))}
        </div>

        {/* Settings Panel */}
        {settings && (
          <div className="card">
            <button onClick={() => setShowSettings(!showSettings)}
              className="w-full p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-surface-500" />
                <div className="text-left">
                  <div className="text-sm font-semibold text-surface-900">Платформ тохиргоо</div>
                  <div className="text-xs text-surface-400">Шимтгэл, даатгал, AI, бүгдийг тохируулах</div>
                </div>
              </div>
              <Lock className="w-4 h-4 text-surface-400" />
            </button>

            {showSettings && (
              <div className="border-t border-surface-100 p-5 space-y-5">
                {/* Config password */}
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <label className="text-xs font-semibold text-amber-800 block mb-2">
                    🔒 Тохиргооны нууц үг (тохиргоо хадгалахад шаардана)
                  </label>
                  <div className="relative">
                    <input type={showPwd ? 'text' : 'password'} value={configPwd}
                      onChange={e => setConfigPwd(e.target.value)}
                      placeholder="Тохиргооны нууц үг" className="input pr-10 bg-white" />
                    <button onClick={() => setShowPwd(!showPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400">
                      {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Finance */}
                <SettingsSection title="💳 Санхүү" items={[
                  { label: 'Гүйлгээний шимтгэл', field: 'defaultPlatformFeeRate', value: settings.defaultPlatformFeeRate, suffix: '%', multiply: 100 },
                  { label: 'Хамгийн бага шимтгэл', field: 'minPlatformFee', value: settings.minPlatformFee, suffix: '₮' },
                  { label: 'Хамгийн их шимтгэл', field: 'maxPlatformFee', value: settings.maxPlatformFee, suffix: '₮' },
                  { label: 'Тооцооны цикл', field: 'settlementCycleDays', value: settings.settlementCycleDays, suffix: ' хоног' },
                ]} editField={editField} setEditField={setEditField} editValue={editValue}
                  setEditValue={setEditValue} saving={saving} onSave={updateSetting} />

                {/* Insurance */}
                <SettingsSection title="🛡️ Даатгал" items={[
                  { label: 'Энгийн хураамж', field: 'insuranceBasicRate', value: settings.insuranceBasicRate, suffix: '%', multiply: 100 },
                  { label: 'Стандарт хураамж', field: 'insuranceStandardRate', value: settings.insuranceStandardRate, suffix: '%', multiply: 100 },
                  { label: 'Премиум хураамж', field: 'insurancePremiumRate', value: settings.insurancePremiumRate, suffix: '%', multiply: 100 },
                  { label: 'Даатгалгүй max нөхөн олговор', field: 'maxCompensationNoInsurance', value: settings.maxCompensationNoInsurance, suffix: '₮' },
                ]} editField={editField} setEditField={setEditField} editValue={editValue}
                  setEditValue={setEditValue} saving={saving} onSave={updateSetting} />

                {/* Toggles */}
                <div>
                  <h4 className="text-xs font-semibold text-surface-500 uppercase tracking-wide mb-3">ON/OFF</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Даатгалын систем', field: 'insuranceEnabled', value: settings.insuranceEnabled },
                      { label: 'Subscription систем', field: 'subscriptionEnabled', value: settings.subscriptionEnabled },
                      { label: 'AI систем', field: 'aiEnabled', value: settings.aiEnabled },
                    ].map(toggle => (
                      <div key={toggle.field} className="flex items-center justify-between py-2">
                        <span className="text-sm text-surface-700">{toggle.label}</span>
                        <button onClick={() => toggleSetting(toggle.field, toggle.value)}
                          className={`transition-colors ${toggle.value ? 'text-zamex-600' : 'text-surface-300'}`}>
                          {toggle.value
                            ? <ToggleRight className="w-8 h-8" />
                            : <ToggleLeft className="w-8 h-8" />
                          }
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

// ═══ Settings Section Component ═══

function SettingsSection({ title, items, editField, setEditField, editValue, setEditValue, saving, onSave }: {
  title: string; items: any[]; editField: string | null; setEditField: (f: string | null) => void;
  editValue: string; setEditValue: (v: string) => void; saving: boolean;
  onSave: (field: string, value: any) => void;
}) {
  return (
    <div>
      <h4 className="text-xs font-semibold text-surface-500 uppercase tracking-wide mb-3">{title}</h4>
      <div className="space-y-1">
        {items.map(item => {
          const displayValue = item.multiply
            ? (Number(item.value) * item.multiply).toFixed(1)
            : Number(item.value).toLocaleString();
          const isEditing = editField === item.field;

          return (
            <div key={item.field} className="flex items-center justify-between py-2">
              <span className="text-sm text-surface-600">{item.label}</span>
              {isEditing ? (
                <div className="flex items-center gap-2">
                  <input type="number" value={editValue} onChange={e => setEditValue(e.target.value)}
                    className="input w-28 text-right text-sm py-1.5" autoFocus />
                  <button onClick={() => {
                    const val = item.multiply ? parseFloat(editValue) / item.multiply : parseFloat(editValue);
                    onSave(item.field, val);
                  }} disabled={saving} className="btn-primary btn-sm">
                    {saving ? '...' : '✓'}
                  </button>
                  <button onClick={() => setEditField(null)} className="btn-ghost btn-sm">✕</button>
                </div>
              ) : (
                <button onClick={() => { setEditField(item.field); setEditValue(displayValue.replace(/,/g, '')); }}
                  className="text-sm font-semibold text-surface-900 hover:text-zamex-600 transition">
                  {displayValue}{item.suffix}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

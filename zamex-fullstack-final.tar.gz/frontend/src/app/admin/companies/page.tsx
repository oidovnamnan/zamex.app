'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Plus, Building2, Edit3, Check, X, Star, Users } from 'lucide-react';
import { api } from '@/lib/api';
import toast from 'react-hot-toast';

export default function AdminCompaniesPage() {
  const router = useRouter();
  const [companies, setCompanies] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', nameEn: '', slug: '', codePrefix: '', phone: '', description: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    try { const { data } = await api.get('/companies'); setCompanies(data.data.companies); } catch {}
  };

  // Company creation would need a backend endpoint - placeholder
  const handleAdd = async () => {
    if (!form.name || !form.codePrefix) { toast.error('Нэр, код оруулна уу'); return; }
    setSaving(true);
    toast.success('Компани нэмэгдлээ (demo)');
    setShowAdd(false); setForm({ name: '', nameEn: '', slug: '', codePrefix: '', phone: '', description: '' });
    setSaving(false);
  };

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="w-4.5 h-4.5" /></button>
            <h1 className="font-semibold text-surface-900">Карго компаниуд</h1>
          </div>
          <button onClick={() => setShowAdd(true)} className="btn-primary btn-sm"><Plus className="w-4 h-4" /> Нэмэх</button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-3">
        {showAdd && (
          <div className="card p-5 border-2 border-zamex-200 space-y-3">
            <h3 className="text-sm font-semibold text-surface-900">Шинэ компани</h3>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="input-label">Нэр *</label><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="input" /></div>
              <div><label className="input-label">Нэр (EN)</label><input value={form.nameEn} onChange={e => setForm({ ...form, nameEn: e.target.value })} className="input" /></div>
              <div><label className="input-label">Код (3-4 үсэг) *</label><input value={form.codePrefix} onChange={e => setForm({ ...form, codePrefix: e.target.value.toUpperCase() })} maxLength={4} className="input font-mono" /></div>
              <div><label className="input-label">Утас</label><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="input" /></div>
            </div>
            <div><label className="input-label">Тайлбар</label><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="input min-h-[60px] resize-none" /></div>
            <div className="flex gap-2">
              <button onClick={handleAdd} disabled={saving} className="btn-primary flex-1">{saving ? '...' : 'Хадгалах'}</button>
              <button onClick={() => setShowAdd(false)} className="btn-secondary">Цуцлах</button>
            </div>
          </div>
        )}

        {companies.map(c => {
          const r = c.ratingsSummary;
          return (
            <div key={c.id} className="card p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-surface-100 text-surface-600 flex items-center justify-center font-mono font-bold text-sm">
                  {c.codePrefix}
                </div>
                <div>
                  <div className="text-sm font-semibold text-surface-900">{c.name}</div>
                  <div className="flex items-center gap-3 text-xs text-surface-400">
                    {r && <span className="flex items-center gap-0.5"><Star className="w-3 h-3 text-amber-400 fill-amber-400" /> {Number(r.averageRating).toFixed(1)} ({r.totalRatings})</span>}
                    {r && <span>{r.totalDelivered || 0} хүргэлт</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={c.isActive ? 'badge-green' : 'badge-red'}>{c.isActive ? 'Идэвхтэй' : 'Идэвхгүй'}</span>
              </div>
            </div>
          );
        })}
      </main>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, DollarSign, CheckCircle2, Clock, Building2, Plus } from 'lucide-react';
import { api } from '@/lib/api';
import toast from 'react-hot-toast';

export default function SettlementsPage() {
  const router = useRouter();
  const [settlements, setSettlements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [companyId, setCompanyId] = useState('');
  const [companies, setCompanies] = useState<any[]>([]);
  const [creating, setCreating] = useState(false);

  useEffect(() => { load(); loadCompanies(); }, []);

  const load = async () => { try { const { data } = await api.get('/settlements?limit=50'); setSettlements(data.data.settlements); } catch {} setLoading(false); };
  const loadCompanies = async () => { try { const { data } = await api.get('/companies'); setCompanies(data.data.companies); } catch {} };

  const generate = async () => {
    if (!companyId) return;
    setCreating(true);
    const end = new Date(); const start = new Date(); start.setDate(start.getDate() - 7);
    try {
      await api.post('/settlements/generate', { companyId, periodStart: start.toISOString(), periodEnd: end.toISOString() });
      toast.success('Settlement үүслээ'); setShowCreate(false); load();
    } catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
    setCreating(false);
  };

  const markTransferred = async (id: string) => {
    try {
      await api.patch(`/settlements/${id}/transfer`, { bankName: 'Khan Bank', bankAccount: '****', transferReference: `TR-${Date.now()}` });
      toast.success('Шилжүүлэг амжилттай'); load();
    } catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
  };

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="w-4.5 h-4.5" /></button>
            <h1 className="font-semibold text-surface-900">Settlement</h1>
          </div>
          <button onClick={() => setShowCreate(true)} className="btn-primary btn-sm"><Plus className="w-4 h-4" /> Шинэ</button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-4">
        {showCreate && (
          <div className="card p-5 border-2 border-zamex-200">
            <h3 className="text-sm font-semibold mb-3">7 хоногийн settlement үүсгэх</h3>
            <select value={companyId} onChange={e => setCompanyId(e.target.value)} className="input mb-3">
              <option value="">Карго сонгох...</option>
              {companies.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <div className="flex gap-2">
              <button onClick={generate} disabled={creating || !companyId} className="btn-primary flex-1">{creating ? 'Үүсгэж байна...' : 'Үүсгэх'}</button>
              <button onClick={() => setShowCreate(false)} className="btn-secondary">Цуцлах</button>
            </div>
          </div>
        )}

        {settlements.map(s => (
          <div key={s.id} className="card p-5">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-surface-400" />
                  <span className="text-sm font-semibold text-surface-900">{s.company?.name}</span>
                  <span className={s.status === 'COMPLETED' ? 'badge-green' : s.status === 'PENDING' ? 'badge-yellow' : 'badge-gray'}>{s.status}</span>
                </div>
                <div className="text-xs text-surface-400 mt-0.5">
                  {new Date(s.periodStart).toLocaleDateString('mn-MN')} — {new Date(s.periodEnd).toLocaleDateString('mn-MN')}
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-surface-900">₮{Number(s.netAmount).toLocaleString()}</div>
                <div className="text-xs text-surface-400">Каргод шилжүүлэх</div>
              </div>
            </div>

            <div className="bg-surface-50 rounded-xl p-3 space-y-1.5 text-xs mb-3">
              <div className="flex justify-between"><span className="text-surface-500">Нийт тээвэр</span><span>₮{Number(s.totalShippingRevenue).toLocaleString()}</span></div>
              <div className="flex justify-between text-red-600"><span>zamex шимтгэл</span><span>-₮{Number(s.totalPlatformFees).toLocaleString()}</span></div>
              <div className="flex justify-between text-red-600"><span>QPay fee</span><span>-₮{Number(s.totalQpayFees).toLocaleString()}</span></div>
              <div className="flex justify-between text-red-600"><span>Буцаалт</span><span>-₮{Number(s.totalRefunds).toLocaleString()}</span></div>
              <div className="flex justify-between font-bold pt-1.5 border-t border-surface-200"><span>Цэвэр дүн</span><span>₮{Number(s.netAmount).toLocaleString()}</span></div>
            </div>

            {s.status === 'PENDING' && (
              <button onClick={() => markTransferred(s.id)} className="btn-primary btn-sm w-full">
                <DollarSign className="w-3.5 h-3.5" /> Шилжүүлсэн гэж тэмдэглэх
              </button>
            )}
            {s.transferredAt && <p className="text-xs text-surface-400 text-center">Шилжүүлсэн: {new Date(s.transferredAt).toLocaleString('mn-MN')}</p>}
          </div>
        ))}

        {!loading && settlements.length === 0 && (
          <div className="card p-12 text-center"><DollarSign className="w-10 h-10 text-surface-200 mx-auto mb-3" /><p className="text-sm text-surface-400">Settlement байхгүй</p></div>
        )}
      </main>
    </div>
  );
}

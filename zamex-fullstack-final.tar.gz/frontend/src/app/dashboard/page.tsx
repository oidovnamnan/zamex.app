'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Package, Plus, Truck, Bell, Star, ChevronRight,
  Shield, Clock, CheckCircle2, AlertCircle, LogOut, User, Copy
} from 'lucide-react';
import { useAuth } from '@/lib/store';
import { api } from '@/lib/api';
import toast from 'react-hot-toast';

const STATUS_MAP: Record<string, { label: string; color: string; dot: string }> = {
  PENDING: { label: 'Хүлээгдэж буй', color: 'badge-gray', dot: 'dot-gray' },
  PRE_ANNOUNCED: { label: 'Tracking оруулсан', color: 'badge-blue', dot: 'dot-blue' },
  MATCHED: { label: 'Бараа ирлээ', color: 'badge-green', dot: 'dot-green' },
  COMPLETED: { label: 'Дууссан', color: 'badge-green', dot: 'dot-green' },
  NOT_RECEIVED: { label: 'Ирээгүй хүсэлт', color: 'badge-yellow', dot: 'dot-yellow' },
};

const PKG_STATUS_MAP: Record<string, { label: string; color: string }> = {
  RECEIVED_IN_CHINA: { label: 'Эрээнд ирсэн', color: 'badge-blue' },
  MEASURED: { label: 'Хэмжигдсэн', color: 'badge-blue' },
  BATCHED: { label: 'Тээвэрт бэлэн', color: 'badge-blue' },
  DEPARTED: { label: 'Замд', color: 'badge-yellow' },
  IN_TRANSIT: { label: 'Замд', color: 'badge-yellow' },
  ARRIVED_MN: { label: 'УБ-д ирсэн', color: 'badge-green' },
  READY_FOR_PICKUP: { label: 'Авахад бэлэн', color: 'badge-green' },
  DELIVERED: { label: 'Олгосон', color: 'badge-gray' },
};

export default function Dashboard() {
  const router = useRouter();
  const { user, loading, fetchMe, logout } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);

  useEffect(() => {
    fetchMe();
  }, []);

  useEffect(() => {
    if (!loading && !user) router.push('/auth');
    if (user) loadOrders();
  }, [user, loading]);

  const loadOrders = async () => {
    try {
      const { data } = await api.get('/orders?limit=50');
      setOrders(data.data.orders);
    } catch { }
    setLoadingOrders(false);
  };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Хуулагдлаа');
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-3 border-zamex-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!user) return null;

  const activeOrders = orders.filter(o => !['COMPLETED', 'CANCELLED', 'EXPIRED'].includes(o.status));
  const completedOrders = orders.filter(o => o.status === 'COMPLETED');

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-zamex-600 flex items-center justify-center">
              <Package className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-surface-900">zamex</span>
          </div>
          <div className="flex items-center gap-1">
            <button className="btn-ghost btn-sm relative">
              <Bell className="w-4.5 h-4.5" />
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">3</span>
            </button>
            <button onClick={() => { logout(); router.push('/auth'); }} className="btn-ghost btn-sm">
              <LogOut className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-5">
        {/* Greeting */}
        <div>
          <h1 className="text-xl font-bold text-surface-900">
            Сайн байна уу, {user.firstName}
          </h1>
          <p className="text-sm text-surface-400 mt-0.5">
            {activeOrders.length > 0 ? `${activeOrders.length} идэвхтэй захиалга` : 'Захиалга байхгүй'}
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => router.push('/orders/new')}
            className="card-hover p-4 flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-xl bg-zamex-50 text-zamex-600 flex items-center justify-center">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-surface-900">Шинэ захиалга</div>
              <div className="text-xs text-surface-400">Бараа захиалах</div>
            </div>
          </button>
          <button onClick={() => router.push('/companies')}
            className="card-hover p-4 flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-surface-900">Карго хайх</div>
              <div className="text-xs text-surface-400">Рейтинг харах</div>
            </div>
          </button>
        </div>

        {/* Active Orders */}
        {activeOrders.length > 0 && (
          <section>
            <h2 className="text-sm font-semibold text-surface-500 uppercase tracking-wide mb-3">
              Идэвхтэй захиалга
            </h2>
            <div className="space-y-2.5">
              {activeOrders.map((order) => (
                <button key={order.id} onClick={() => router.push(`/orders/${order.id}`)}
                  className="card-hover p-4 w-full text-left">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-semibold text-surface-900 truncate">
                          {order.productTitle || order.orderCode}
                        </span>
                      </div>
                      <div className="text-xs text-surface-400 font-mono">{order.orderCode}</div>

                      {/* Package status */}
                      {order.package ? (
                        <div className="mt-2">
                          <span className={PKG_STATUS_MAP[order.package.status]?.color || 'badge-gray'}>
                            {PKG_STATUS_MAP[order.package.status]?.label || order.package.status}
                          </span>
                          {order.package.weightKg && (
                            <span className="text-xs text-surface-400 ml-2">{order.package.weightKg}кг</span>
                          )}
                          {order.package.shippingCost && (
                            <span className="text-xs text-surface-400 ml-2">₮{Number(order.package.shippingCost).toLocaleString()}</span>
                          )}
                        </div>
                      ) : (
                        <div className="mt-2">
                          <span className={STATUS_MAP[order.status]?.color || 'badge-gray'}>
                            {STATUS_MAP[order.status]?.label || order.status}
                          </span>
                        </div>
                      )}
                    </div>
                    <ChevronRight className="w-4 h-4 text-surface-300 mt-1 flex-shrink-0" />
                  </div>

                  {/* Copy address button */}
                  {order.status === 'PENDING' && (
                    <div className="mt-3 pt-3 border-t border-surface-100">
                      <button onClick={(e) => { e.stopPropagation(); copyText(order.shippingAddress?.copy_all || ''); }}
                        className="btn-secondary btn-sm w-full">
                        <Copy className="w-3.5 h-3.5" /> Хаяг хуулах
                      </button>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Completed */}
        {completedOrders.length > 0 && (
          <section>
            <h2 className="text-sm font-semibold text-surface-500 uppercase tracking-wide mb-3">
              Дууссан ({completedOrders.length})
            </h2>
            <div className="space-y-2">
              {completedOrders.slice(0, 5).map((order) => (
                <button key={order.id} onClick={() => router.push(`/orders/${order.id}`)}
                  className="card p-3.5 w-full text-left flex items-center justify-between opacity-70 hover:opacity-100 transition">
                  <div>
                    <div className="text-sm font-medium text-surface-700">{order.productTitle || order.orderCode}</div>
                    <div className="text-xs text-surface-400">{order.orderCode}</div>
                  </div>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Empty state */}
        {orders.length === 0 && !loadingOrders && (
          <div className="card p-12 text-center">
            <Package className="w-12 h-12 text-surface-200 mx-auto mb-4" />
            <h3 className="text-base font-semibold text-surface-700 mb-1">Захиалга байхгүй</h3>
            <p className="text-sm text-surface-400 mb-5">Эхлээд карго сонгоод захиалга үүсгээрэй</p>
            <button onClick={() => router.push('/companies')} className="btn-primary">
              Карго сонгох
            </button>
          </div>
        )}
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-surface-100 pb-safe z-40">
        <div className="max-w-2xl mx-auto flex">
          {[
            { icon: <Package className="w-5 h-5" />, label: 'Нүүр', href: '/dashboard', active: true },
            { icon: <Truck className="w-5 h-5" />, label: 'Карго', href: '/companies' },
            { icon: <Plus className="w-6 h-6" />, label: 'Захиалга', href: '/orders/new', primary: true },
            { icon: <Star className="w-5 h-5" />, label: 'Үнэлгээ', href: '/ratings' },
            { icon: <User className="w-5 h-5" />, label: 'Профайл', href: '/profile' },
          ].map((item) => (
            <button key={item.label} onClick={() => router.push(item.href)}
              className={`flex-1 flex flex-col items-center py-2 ${item.primary
                ? 'text-zamex-600'
                : item.active ? 'text-zamex-600' : 'text-surface-400'}`}>
              {item.icon}
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

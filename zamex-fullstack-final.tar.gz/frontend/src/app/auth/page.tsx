'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Package, ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

export default function AuthPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialMode = searchParams.get('mode') === 'register' ? 'register' : 'login';

  const [mode, setMode] = useState<'login' | 'register' | 'otp'>(initialMode);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [otp, setOtp] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  const { login, register, verifyOtp } = useAuth();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await login(phone, password);
      if (data.data.requireOtp) {
        setMode('otp');
        toast.success('OTP код илгээлээ');
      } else {
        toast.success('Амжилттай нэвтэрлээ');
        router.push('/dashboard');
      }
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Нэвтрэхэд алдаа гарлаа');
    }
    setLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(phone, firstName, password);
      setMode('otp');
      toast.success('OTP код илгээлээ');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Бүртгэлд алдаа гарлаа');
    }
    setLoading(false);
  };

  const handleOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await verifyOtp(phone, otp);
      toast.success('Амжилттай!');
      router.push('/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'OTP буруу');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-50 px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-zamex-600 flex items-center justify-center mx-auto mb-4">
            <Package className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold text-surface-900">zamex.app</h1>
          <p className="text-sm text-surface-400 mt-1">Карго удирдлагын систем</p>
        </div>

        <div className="card p-6">
          {/* OTP */}
          {mode === 'otp' && (
            <form onSubmit={handleOtp}>
              <button type="button" onClick={() => setMode('login')} className="btn-ghost btn-sm mb-4 -ml-2">
                <ArrowLeft className="w-4 h-4" /> Буцах
              </button>
              <h2 className="text-lg font-semibold text-surface-900 mb-1">OTP баталгаажуулах</h2>
              <p className="text-sm text-surface-400 mb-5">{phone} дугаар руу код илгээсэн</p>
              <div className="mb-4">
                <input
                  type="text"
                  maxLength={4}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="4 оронтой код"
                  className="input text-center text-2xl tracking-[0.5em] font-mono"
                  autoFocus
                />
              </div>
              <button type="submit" disabled={otp.length !== 4 || loading} className="btn-primary w-full">
                {loading ? 'Шалгаж байна...' : 'Баталгаажуулах'}
              </button>
            </form>
          )}

          {/* Login */}
          {mode === 'login' && (
            <form onSubmit={handleLogin}>
              <h2 className="text-lg font-semibold text-surface-900 mb-5">Нэвтрэх</h2>
              <div className="space-y-3.5">
                <div>
                  <label className="input-label">Утасны дугаар</label>
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)}
                    placeholder="99112233" className="input" autoFocus />
                </div>
                <div>
                  <label className="input-label">Нууц үг</label>
                  <div className="relative">
                    <input type={showPwd ? 'text' : 'password'} value={password}
                      onChange={(e) => setPassword(e.target.value)} placeholder="••••••" className="input pr-10" />
                    <button type="button" onClick={() => setShowPwd(!showPwd)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600">
                      {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
              <button type="submit" disabled={!phone || !password || loading} className="btn-primary w-full mt-5">
                {loading ? 'Нэвтэрч байна...' : 'Нэвтрэх'}
              </button>
              <p className="text-center text-sm text-surface-400 mt-4">
                Бүртгэл байхгүй юу?{' '}
                <button type="button" onClick={() => setMode('register')} className="text-zamex-600 font-medium hover:underline">
                  Бүртгүүлэх
                </button>
              </p>
            </form>
          )}

          {/* Register */}
          {mode === 'register' && (
            <form onSubmit={handleRegister}>
              <h2 className="text-lg font-semibold text-surface-900 mb-5">Бүртгүүлэх</h2>
              <div className="space-y-3.5">
                <div>
                  <label className="input-label">Нэр</label>
                  <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Бат-Эрдэнэ" className="input" autoFocus />
                </div>
                <div>
                  <label className="input-label">Утасны дугаар</label>
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)}
                    placeholder="99112233" className="input" />
                </div>
                <div>
                  <label className="input-label">Нууц үг</label>
                  <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                    placeholder="6+ тэмдэгт" className="input" />
                </div>
              </div>
              <button type="submit" disabled={!firstName || !phone || password.length < 6 || loading}
                className="btn-primary w-full mt-5">
                {loading ? 'Бүртгэж байна...' : 'Бүртгүүлэх'}
              </button>
              <p className="text-center text-sm text-surface-400 mt-4">
                Бүртгэлтэй юу?{' '}
                <button type="button" onClick={() => setMode('login')} className="text-zamex-600 font-medium hover:underline">
                  Нэвтрэх
                </button>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, Link2, Image, Shield, Copy, Check, Package, ChevronDown } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

const INSURANCE_PLANS = [
  {
    slug: null, name: 'Даатгалгүй', desc: 'Каргоны стандарт нөхцөл', price: '₮0',
    icon: '—', color: 'border-surface-200',
  },
  {
    slug: 'BASIC', name: 'Энгийн', desc: '50% нөхнө, ₮500K хүртэл', price: '3%',
    icon: '🟢', color: 'border-emerald-200 bg-emerald-50/30',
  },
  {
    slug: 'STANDARD', name: 'Стандарт', desc: '80% нөхнө, ₮2M хүртэл', price: '5%',
    icon: '🔵', color: 'border-blue-200 bg-blue-50/30', recommended: true,
  },
  {
    slug: 'PREMIUM', name: 'Премиум', desc: '100% нөхнө, ₮10M хүртэл', price: '8%',
    icon: '🟡', color: 'border-amber-200 bg-amber-50/30',
  },
];

export default function NewOrderPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();

  const [step, setStep] = useState(1); // 1: info, 2: insurance, 3: done
  const [submitting, setSubmitting] = useState(false);

  // Form
  const [companyId, setCompanyId] = useState(searchParams.get('companyId') || '');
  const [productUrl, setProductUrl] = useState('');
  const [productTitle, setProductTitle] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [insurancePlan, setInsurancePlan] = useState<string | null>(null);

  // Result
  const [result, setResult] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  const companies = user?.customerCompanies || [];

  const handleSubmit = async () => {
    if (!companyId) { toast.error('Карго сонгоно уу'); return; }
    setSubmitting(true);
    try {
      const body: any = { companyId };
      if (productUrl) body.productUrl = productUrl;
      if (productTitle) body.productTitle = productTitle;
      if (productPrice) body.productPrice = parseFloat(productPrice);
      if (productDescription) body.productDescription = productDescription;
      if (trackingNumber) body.trackingNumber = trackingNumber;
      if (insurancePlan) body.insurancePlanSlug = insurancePlan;

      const { data } = await api.post('/orders', body);
      setResult(data.data.order);
      setStep(3);
      toast.success('Захиалга үүслээ!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Алдаа гарлаа');
    }
    setSubmitting(false);
  };

  const copyAddress = () => {
    if (result?.shippingAddress?.copy_all) {
      navigator.clipboard.writeText(result.shippingAddress.copy_all);
      setCopied(true);
      toast.success('Хаяг хуулагдлаа!');
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => step > 1 && step < 3 ? setStep(step - 1) : router.back()} className="btn-ghost btn-sm -ml-2">
            <ArrowLeft className="w-4.5 h-4.5" />
          </button>
          <h1 className="font-semibold text-surface-900">
            {step === 3 ? 'Захиалга үүслээ' : 'Шинэ захиалга'}
          </h1>
        </div>
        {/* Progress */}
        {step < 3 && (
          <div className="max-w-2xl mx-auto px-4 pb-2 flex gap-1.5">
            {[1, 2].map(s => (
              <div key={s} className={`h-1 flex-1 rounded-full transition-colors ${s <= step ? 'bg-zamex-500' : 'bg-surface-200'}`} />
            ))}
          </div>
        )}
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5">

        {/* Step 1: Product Info */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="input-label">Карго компани *</label>
              <select value={companyId} onChange={e => setCompanyId(e.target.value)}
                className="input">
                <option value="">Сонгох...</option>
                {companies.map((cc: any) => (
                  <option key={cc.company.id} value={cc.company.id}>
                    {cc.company.name} ({cc.customerCode})
                  </option>
                ))}
              </select>
              {companies.length === 0 && (
                <p className="text-xs text-amber-600 mt-1">
                  Эхлээд каргод бүртгүүлнэ үү →{' '}
                  <button onClick={() => router.push('/companies')} className="underline">Карго хайх</button>
                </p>
              )}
            </div>

            <div>
              <label className="input-label">
                <Link2 className="w-3.5 h-3.5 inline" /> Бараа линк
              </label>
              <input value={productUrl} onChange={e => setProductUrl(e.target.value)}
                placeholder="https://item.taobao.com/..." className="input" />
              <p className="text-xs text-surface-400 mt-1">Taobao, 1688, JD линк оруулна уу</p>
            </div>

            <div>
              <label className="input-label">Барааны нэр</label>
              <input value={productTitle} onChange={e => setProductTitle(e.target.value)}
                placeholder="iPhone 15 гэр" className="input" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="input-label">Үнэ (¥)</label>
                <input type="number" value={productPrice} onChange={e => setProductPrice(e.target.value)}
                  placeholder="199" className="input" />
              </div>
              <div>
                <label className="input-label">Tracking (байвал)</label>
                <input value={trackingNumber} onChange={e => setTrackingNumber(e.target.value)}
                  placeholder="SF1234..." className="input" />
              </div>
            </div>

            <div>
              <label className="input-label">Тайлбар</label>
              <textarea value={productDescription} onChange={e => setProductDescription(e.target.value)}
                placeholder="Цагаан өнгө, 256GB гэх мэт" className="input min-h-[70px] resize-none" />
            </div>

            <button onClick={() => setStep(2)} disabled={!companyId}
              className="btn-primary w-full mt-2">
              Үргэлжлүүлэх
            </button>
          </div>
        )}

        {/* Step 2: Insurance */}
        {step === 2 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-base font-semibold text-surface-900 mb-1">
                <Shield className="w-4.5 h-4.5 inline text-zamex-600" /> Даатгал сонгох
              </h2>
              <p className="text-sm text-surface-400">
                Бараа эвдэрсэн, алга болсон тохиолдолд нөхөн олговор авна
              </p>
            </div>

            <div className="space-y-2.5">
              {INSURANCE_PLANS.map(plan => (
                <button key={plan.slug || 'none'}
                  onClick={() => setInsurancePlan(plan.slug)}
                  className={`card p-4 w-full text-left border-2 transition-all ${
                    insurancePlan === plan.slug
                      ? 'border-zamex-500 ring-2 ring-zamex-500/10'
                      : plan.color
                  }`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span>{plan.icon}</span>
                        <span className="text-sm font-semibold text-surface-900">{plan.name}</span>
                        {plan.recommended && <span className="badge-blue">Санал болгох</span>}
                      </div>
                      <p className="text-xs text-surface-400">{plan.desc}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-surface-900">{plan.price}</div>
                      {insurancePlan === plan.slug && (
                        <Check className="w-5 h-5 text-zamex-600 mt-1 ml-auto" />
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <button onClick={handleSubmit} disabled={submitting}
              className="btn-primary w-full mt-2">
              {submitting ? 'Үүсгэж байна...' : 'Захиалга үүсгэх'}
            </button>
          </div>
        )}

        {/* Step 3: Success - Copy Address */}
        {step === 3 && result && (
          <div className="space-y-5">
            <div className="text-center pt-4 pb-2">
              <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-xl font-bold text-surface-900 mb-1">Захиалга үүслээ!</h2>
              <p className="text-sm text-surface-400">Доорх хаягийг хуулж Taobao/1688-д оруулна уу</p>
            </div>

            <div className="card border-2 border-zamex-200 bg-zamex-50/30 p-5">
              <div className="text-xs font-semibold text-zamex-600 uppercase tracking-wide mb-3">
                Хүргэлтийн хаяг
              </div>
              <div className="bg-white rounded-xl p-4 font-mono text-sm text-surface-800 leading-relaxed whitespace-pre-line">
                {result.shippingAddress?.copy_all}
              </div>
              <button onClick={copyAddress}
                className={`w-full mt-3 ${copied ? 'btn bg-emerald-600 text-white' : 'btn-primary'}`}>
                {copied ? <><Check className="w-4 h-4" /> Хуулагдлаа!</> : <><Copy className="w-4 h-4" /> Хаяг бүгдийг хуулах</>}
              </button>
            </div>

            <div className="card p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-surface-500">Захиалгын код</span>
                <span className="font-mono font-semibold text-surface-900">{result.orderCode}</span>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
              ⚠️ Хүлээн авагчийн нэрний ард дахь <strong>{result.orderCode}</strong> кодыг заавал оруулна уу!
              Энэ код байхгүй бол бараа таньд хүрэхгүй.
            </div>

            <div className="flex gap-3">
              <button onClick={() => router.push('/dashboard')} className="btn-secondary flex-1">
                Нүүр хуудас
              </button>
              <button onClick={() => { setStep(1); setResult(null); setProductUrl(''); setProductTitle(''); setProductPrice(''); setProductDescription(''); setTrackingNumber(''); }}
                className="btn-primary flex-1">
                <Plus className="w-4 h-4" /> Дахин захиалга
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Plus(props: any) { return <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>; }

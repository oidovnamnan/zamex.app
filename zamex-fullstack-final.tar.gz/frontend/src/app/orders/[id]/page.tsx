'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import {
  ArrowLeft, Copy, Package, Truck, MapPin, Shield, Clock,
  CheckCircle2, AlertTriangle, CreditCard, Star, ChevronRight,
  ExternalLink, Camera, RotateCcw
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

const TIMELINE_STEPS = [
  { key: 'PENDING', label: 'Захиалга үүссэн', icon: Package },
  { key: 'RECEIVED_IN_CHINA', label: 'Эрээнд ирсэн', icon: MapPin },
  { key: 'DEPARTED', label: 'Тээвэрт гарсан', icon: Truck },
  { key: 'ARRIVED_MN', label: 'УБ-д ирсэн', icon: MapPin },
  { key: 'READY_FOR_PICKUP', label: 'Авахад бэлэн', icon: CreditCard },
  { key: 'DELIVERED', label: 'Олгосон', icon: CheckCircle2 },
];

const STATUS_ORDER = ['PENDING', 'PRE_ANNOUNCED', 'RECEIVED_IN_CHINA', 'MEASURED', 'CATEGORIZED',
  'SHELVED_CHINA', 'BATCHED', 'DEPARTED', 'IN_TRANSIT', 'AT_CUSTOMS', 'CUSTOMS_CLEARED',
  'ARRIVED_MN', 'SHELVED_MN', 'READY_FOR_PICKUP', 'DELIVERED'];

export default function OrderDetailPage() {
  const router = useRouter();
  const { id } = useParams();
  const { user } = useAuth();
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadOrder(); }, [id]);

  const loadOrder = async () => {
    try {
      const { data } = await api.get(`/orders/${id}`);
      setOrder(data.data.order);
    } catch { toast.error('Захиалга олдсонгүй'); router.back(); }
    setLoading(false);
  };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Хуулагдлаа');
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-3 border-zamex-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!order) return null;

  const pkg = order.package;
  const ins = order.insurance;
  const currentStatus = pkg?.status || order.status;
  const currentIdx = STATUS_ORDER.indexOf(currentStatus);

  const getStepState = (stepKey: string) => {
    const stepIdx = STATUS_ORDER.indexOf(stepKey);
    if (stepIdx < 0) return 'upcoming';
    if (currentIdx >= stepIdx) return 'completed';
    if (currentIdx === stepIdx - 1) return 'current';
    return 'upcoming';
  };

  return (
    <div className="min-h-screen bg-surface-50 pb-24">
      {/* Header */}
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2">
            <ArrowLeft className="w-4.5 h-4.5" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-semibold text-surface-900 truncate">
              {order.productTitle || 'Захиалга'}
            </h1>
            <p className="text-xs text-surface-400 font-mono">{order.orderCode}</p>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-5 space-y-4">

        {/* Tracking Timeline */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-surface-900 mb-4">Барааны явц</h3>
          <div className="space-y-0">
            {TIMELINE_STEPS.map((step, i) => {
              const state = getStepState(step.key);
              const Icon = step.icon;
              const isLast = i === TIMELINE_STEPS.length - 1;

              return (
                <div key={step.key} className="flex gap-3">
                  {/* Line + dot */}
                  <div className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      state === 'completed' ? 'bg-emerald-100 text-emerald-600' :
                      state === 'current' ? 'bg-zamex-100 text-zamex-600 ring-2 ring-zamex-500/30' :
                      'bg-surface-100 text-surface-300'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    {!isLast && (
                      <div className={`w-0.5 h-8 ${state === 'completed' ? 'bg-emerald-200' : 'bg-surface-200'}`} />
                    )}
                  </div>
                  {/* Label */}
                  <div className="pt-1.5 pb-4">
                    <div className={`text-sm font-medium ${
                      state === 'completed' ? 'text-surface-900' :
                      state === 'current' ? 'text-zamex-700' :
                      'text-surface-400'
                    }`}>
                      {step.label}
                    </div>
                    {/* Timestamps */}
                    {state === 'completed' && step.key === 'RECEIVED_IN_CHINA' && pkg?.receivedAt && (
                      <p className="text-xs text-surface-400 mt-0.5">
                        {new Date(pkg.receivedAt).toLocaleDateString('mn-MN')}
                      </p>
                    )}
                    {state === 'completed' && step.key === 'DEPARTED' && pkg?.departedAt && (
                      <p className="text-xs text-surface-400 mt-0.5">
                        {new Date(pkg.departedAt).toLocaleDateString('mn-MN')}
                      </p>
                    )}
                    {state === 'completed' && step.key === 'ARRIVED_MN' && pkg?.arrivedMnAt && (
                      <p className="text-xs text-surface-400 mt-0.5">
                        {new Date(pkg.arrivedMnAt).toLocaleDateString('mn-MN')}
                      </p>
                    )}
                    {state === 'completed' && step.key === 'DELIVERED' && pkg?.deliveredAt && (
                      <p className="text-xs text-surface-400 mt-0.5">
                        {new Date(pkg.deliveredAt).toLocaleDateString('mn-MN')}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Package Info */}
        {pkg && (
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-surface-900 mb-3">Барааны мэдээлэл</h3>
            <div className="space-y-2.5 text-sm">
              {pkg.weightKg && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Жин</span>
                  <span className="font-medium text-surface-900">{pkg.weightKg} кг</span>
                </div>
              )}
              {(pkg.lengthCm && pkg.widthCm && pkg.heightCm) && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Овор</span>
                  <span className="font-medium text-surface-900">{pkg.lengthCm}×{pkg.widthCm}×{pkg.heightCm} см</span>
                </div>
              )}
              {pkg.category && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Ангилал</span>
                  <span className="font-medium text-surface-900">{pkg.category.name}</span>
                </div>
              )}
              {pkg.shippingCost && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Тээврийн зардал</span>
                  <span className="font-bold text-surface-900">₮{Number(pkg.shippingCost).toLocaleString()}</span>
                </div>
              )}
              {pkg.shelfLocation && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Тавиур</span>
                  <span className="font-mono text-surface-700">{pkg.shelfLocation}</span>
                </div>
              )}
              {pkg.batch && (
                <div className="flex justify-between">
                  <span className="text-surface-500">Batch</span>
                  <span className="font-mono text-surface-700">{pkg.batch.batchCode}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Insurance */}
        {ins && (
          <div className="card p-5 border-l-4 border-l-zamex-500">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4.5 h-4.5 text-zamex-600" />
              <h3 className="text-sm font-semibold text-surface-900">Даатгал</h3>
              <span className="badge-blue">{ins.planSlug}</span>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-surface-500">Хураамж</span>
                <span className="font-medium">₮{Number(ins.premium).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-surface-500">Нөхөн олговрын дээд</span>
                <span className="font-medium">₮{Number(ins.maxPayout).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-surface-500">Хамрах хувь</span>
                <span className="font-medium">{Number(ins.coverageRate) * 100}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-surface-500">Төлөв</span>
                <span className={ins.status === 'ACTIVE' ? 'badge-green' : 'badge-gray'}>{ins.status}</span>
              </div>
            </div>
          </div>
        )}

        {/* Shipping Address */}
        {order.shippingAddress && order.status !== 'COMPLETED' && (
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-surface-900 mb-3">Хүргэлтийн хаяг</h3>
            <div className="bg-surface-50 rounded-xl p-3 font-mono text-xs text-surface-700 leading-relaxed whitespace-pre-line mb-3">
              {order.shippingAddress.copy_all}
            </div>
            <button onClick={() => copyText(order.shippingAddress.copy_all)} className="btn-secondary btn-sm w-full">
              <Copy className="w-3.5 h-3.5" /> Хаяг хуулах
            </button>
          </div>
        )}

        {/* Product Info */}
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-surface-900 mb-3">Захиалгын мэдээлэл</h3>
          <div className="space-y-2.5 text-sm">
            <div className="flex justify-between">
              <span className="text-surface-500">Карго</span>
              <span className="font-medium text-surface-900">{order.company?.name}</span>
            </div>
            {order.productTitle && (
              <div className="flex justify-between">
                <span className="text-surface-500">Бараа</span>
                <span className="font-medium text-surface-900 text-right max-w-[60%] truncate">{order.productTitle}</span>
              </div>
            )}
            {order.productUrl && (
              <div className="flex justify-between items-center">
                <span className="text-surface-500">Линк</span>
                <a href={order.productUrl} target="_blank" rel="noopener"
                  className="text-zamex-600 text-xs flex items-center gap-1 hover:underline">
                  {order.productPlatform || 'Харах'} <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
            {order.trackingNumber && (
              <div className="flex justify-between">
                <span className="text-surface-500">Tracking</span>
                <button onClick={() => copyText(order.trackingNumber)}
                  className="font-mono text-xs text-surface-700 flex items-center gap-1 hover:text-zamex-600">
                  {order.trackingNumber} <Copy className="w-3 h-3" />
                </button>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-surface-500">Огноо</span>
              <span className="text-surface-700">{new Date(order.createdAt).toLocaleDateString('mn-MN')}</span>
            </div>
          </div>
        </div>

        {/* Returns */}
        {order.returnRequests?.length > 0 && (
          <div className="card p-5">
            <h3 className="text-sm font-semibold text-surface-900 mb-3">Буцаалтууд</h3>
            <div className="space-y-2">
              {order.returnRequests.map((r: any) => (
                <button key={r.id} onClick={() => router.push(`/returns/${r.id}`)}
                  className="w-full p-3 rounded-xl bg-surface-50 flex items-center justify-between hover:bg-surface-100 transition">
                  <div>
                    <span className="text-xs font-mono text-surface-500">{r.returnCode}</span>
                    <span className={`ml-2 ${r.status === 'OPENED' ? 'badge-yellow' : r.status === 'APPROVED' ? 'badge-green' : 'badge-gray'}`}>
                      {r.status}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-surface-300" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2.5">
          {/* Return button */}
          {pkg && ['DELIVERED', 'READY_FOR_PICKUP', 'ARRIVED_MN'].includes(pkg.status) && order.status !== 'CANCELLED' && (
            <button onClick={() => router.push(`/returns/new?orderId=${order.id}`)}
              className="btn-secondary w-full text-amber-700 border-amber-200 hover:bg-amber-50">
              <RotateCcw className="w-4 h-4" /> Буцаалт нээх
            </button>
          )}

          {/* Rate button */}
          {order.status === 'COMPLETED' && !order.rating && (
            <button onClick={() => router.push(`/ratings/new?orderId=${order.id}`)}
              className="btn-primary w-full">
              <Star className="w-4 h-4" /> Үнэлгээ өгөх
            </button>
          )}
        </div>
      </main>
    </div>
  );
}

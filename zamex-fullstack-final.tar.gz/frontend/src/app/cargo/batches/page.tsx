'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft, Plus, Truck, Package, Check, X, Play,
  MapPin, RefreshCw, ChevronDown, ChevronRight
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

export default function BatchesPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [batches, setBatches] = useState<any[]>([]);
  const [packages, setPackages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [vehicleInfo, setVehicleInfo] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState<string | null>(null);
  const [selectedPkgs, setSelectedPkgs] = useState<string[]>([]);
  const [adding, setAdding] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    try {
      const [b, p] = await Promise.all([
        api.get('/batches?limit=50'),
        api.get('/packages?status=RECEIVED_IN_CHINA&limit=100'),
      ]);
      setBatches(b.data.data.batches);
      setPackages(p.data.data.packages.filter((p: any) => !p.batchId));
    } catch {} setLoading(false);
  };

  const createBatch = async () => {
    if (!user?.companyId) return;
    setCreating(true);
    try {
      await api.post('/batches', { companyId: user.companyId, vehicleInfo });
      toast.success('Batch үүслээ');
      setShowCreate(false); setVehicleInfo('');
      load();
    } catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
    setCreating(false);
  };

  const addPackages = async (batchId: string) => {
    if (!selectedPkgs.length) { toast.error('Бараа сонгоно уу'); return; }
    setAdding(true);
    try {
      const { data } = await api.post(`/batches/${batchId}/packages`, { packageIds: selectedPkgs });
      toast.success(data.message);
      setSelectedPkgs([]); setSelectedBatch(null);
      load();
    } catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
    setAdding(false);
  };

  const closeBatch = async (id: string) => {
    try { await api.patch(`/batches/${id}/close`); toast.success('Batch хаагдлаа'); load(); }
    catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
  };

  const departBatch = async (id: string) => {
    try { await api.patch(`/batches/${id}/depart`, {}); toast.success('Тээвэрт гарлаа'); load(); }
    catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
  };

  const arriveBatch = async (id: string) => {
    try { await api.patch(`/batches/${id}/arrive`); toast.success('УБ-д ирлээ!'); load(); }
    catch (err: any) { toast.error(err.response?.data?.error || 'Алдаа'); }
  };

  const togglePkg = (id: string) => {
    setSelectedPkgs(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  };

  const STATUS_ACTIONS: Record<string, { label: string; action: (id: string) => void; color: string }[]> = {
    OPEN: [
      { label: 'Хаах', action: closeBatch, color: 'btn-secondary' },
    ],
    CLOSED: [
      { label: 'Тээвэрт гаргах', action: departBatch, color: 'btn-primary' },
    ],
    DEPARTED: [
      { label: 'УБ-д ирсэн', action: arriveBatch, color: 'btn bg-emerald-600 text-white hover:bg-emerald-700' },
    ],
  };

  return (
    <div className="min-h-screen bg-surface-50">
      <header className="bg-white border-b border-surface-100 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="btn-ghost btn-sm -ml-2"><ArrowLeft className="w-4.5 h-4.5" /></button>
            <h1 className="font-semibold text-surface-900">Batch удирдлага</h1>
          </div>
          <button onClick={() => setShowCreate(true)} className="btn-primary btn-sm"><Plus className="w-4 h-4" /> Шинэ</button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-4">
        {/* Create */}
        {showCreate && (
          <div className="card p-5 border-2 border-zamex-200">
            <h3 className="text-sm font-semibold text-surface-900 mb-3">Шинэ Batch</h3>
            <input value={vehicleInfo} onChange={e => setVehicleInfo(e.target.value)}
              placeholder="Машины мэдээлэл (сонголтоор)" className="input mb-3" />
            <div className="flex gap-2">
              <button onClick={createBatch} disabled={creating} className="btn-primary flex-1">
                {creating ? 'Үүсгэж байна...' : 'Batch үүсгэх'}
              </button>
              <button onClick={() => setShowCreate(false)} className="btn-secondary">Цуцлах</button>
            </div>
          </div>
        )}

        {/* Batches */}
        {batches.map(batch => {
          const actions = STATUS_ACTIONS[batch.status] || [];
          const isOpen = batch.status === 'OPEN';
          const isSelected = selectedBatch === batch.id;

          return (
            <div key={batch.id} className="card">
              <div className="p-4 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-bold text-surface-900">{batch.batchCode}</span>
                    <StatusBadge status={batch.status} />
                  </div>
                  <div className="text-xs text-surface-400 mt-0.5">
                    {batch.totalPackages} бараа • {Number(batch.totalWeight).toFixed(1)}кг
                    {batch.vehicleInfo && ` • ${batch.vehicleInfo}`}
                  </div>
                </div>
                <div className="flex gap-2">
                  {isOpen && (
                    <button onClick={() => setSelectedBatch(isSelected ? null : batch.id)}
                      className="btn-secondary btn-sm">
                      <Plus className="w-3.5 h-3.5" /> Бараа нэмэх
                    </button>
                  )}
                  {actions.map(a => (
                    <button key={a.label} onClick={() => a.action(batch.id)} className={`${a.color} btn-sm`}>
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Add packages panel */}
              {isSelected && (
                <div className="border-t border-surface-100 p-4">
                  <h4 className="text-xs font-semibold text-surface-500 mb-2">
                    Бараа сонгох ({selectedPkgs.length} сонгосон)
                  </h4>
                  {packages.length === 0 ? (
                    <p className="text-xs text-surface-400 py-4 text-center">Нэмэх бараа алга</p>
                  ) : (
                    <div className="space-y-1 max-h-60 overflow-y-auto">
                      {packages.map(pkg => (
                        <button key={pkg.id} onClick={() => togglePkg(pkg.id)}
                          className={`w-full p-2.5 rounded-lg flex items-center gap-2 text-left text-sm transition ${
                            selectedPkgs.includes(pkg.id) ? 'bg-zamex-50 border border-zamex-300' : 'hover:bg-surface-50'
                          }`}>
                          <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                            selectedPkgs.includes(pkg.id) ? 'border-zamex-600 bg-zamex-600' : 'border-surface-300'
                          }`}>
                            {selectedPkgs.includes(pkg.id) && <Check className="w-3 h-3 text-white" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <span className="font-mono text-xs">{pkg.order?.orderCode || pkg.trackingNumber || pkg.id.slice(0, 8)}</span>
                            {pkg.weightKg && <span className="text-surface-400 ml-2">{pkg.weightKg}кг</span>}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                  {selectedPkgs.length > 0 && (
                    <button onClick={() => addPackages(batch.id)} disabled={adding}
                      className="btn-primary w-full mt-3">
                      {adding ? 'Нэмж байна...' : `${selectedPkgs.length} бараа нэмэх`}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {!loading && batches.length === 0 && (
          <div className="card p-12 text-center">
            <Truck className="w-12 h-12 text-surface-200 mx-auto mb-4" />
            <p className="text-sm text-surface-400">Batch байхгүй</p>
            <button onClick={() => setShowCreate(true)} className="btn-primary mt-4">Batch үүсгэх</button>
          </div>
        )}
      </main>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const m: Record<string, string> = { OPEN: 'badge-blue', CLOSED: 'badge-gray', DEPARTED: 'badge-yellow', IN_TRANSIT: 'badge-yellow', ARRIVED: 'badge-green', UNLOADED: 'badge-green' };
  return <span className={m[status] || 'badge-gray'}>{status}</span>;
}

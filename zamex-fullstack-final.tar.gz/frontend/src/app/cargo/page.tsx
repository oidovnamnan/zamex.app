'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Package, Truck, AlertTriangle, Star, Users, BarChart3,
  ChevronRight, Clock, CheckCircle2, XCircle, TrendingUp,
  Box, Scale, QrCode, RefreshCw
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/store';
import toast from 'react-hot-toast';

export default function CargoAdminDashboard() {
  const router = useRouter();
  const { user, loading, fetchMe } = useAuth();
  const [packages, setPackages] = useState<any[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [returns, setReturns] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, china: 0, transit: 0, ub: 0, ready: 0, pendingReturns: 0 });

  useEffect(() => { fetchMe(); }, []);
  useEffect(() => {
    if (user && ['CARGO_ADMIN', 'SUPER_ADMIN'].includes(user.role)) loadData();
  }, [user]);

  const loadData = async () => {
    try {
      const [pkgRes, batchRes, retRes] = await Promise.all([
        api.get('/packages?limit=50'),
        api.get('/batches?limit=10'),
        api.get('/returns?status=OPENED&limit=10'),
      ]);
      const pkgs = pkgRes.data.data.packages;
      setPackages(pkgs);
      setBatches(batchRes.data.data.batches);
      setReturns(retRes.data.data.returns);

      setStats({
        total: pkgRes.data.data.total,
        china: pkgs.filter((p: any) => ['RECEIVED_IN_CHINA', 'MEASURED', 'CATEGORIZED', 'SHELVED_CHINA', 'BATCHED'].includes(p.status)).length,
        transit: pkgs.filter((p: any) => ['DEPARTED', 'IN_TRANSIT', 'AT_CUSTOMS'].includes(p.status)).length,
        ub: pkgs.filter((p: any) => ['ARRIVED_MN', 'SHELVED_MN'].includes(p.status)).length,
        ready: pkgs.filter((p: any) => p.status === 'READY_FOR_PICKUP').length,
        pendingReturns: retRes.data.data.total,
      });
    } catch {}
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-3 border-zamex-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-50">
      {/* Header */}
      <header className="bg-white border-b border-surface-100">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zamex-600 flex items-center justify-center">
              <Package className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold text-surface-900">Cargo Admin</div>
              <div className="text-xs text-surface-400">{user?.firstName}</div>
            </div>
          </div>
          <button onClick={loadData} className="btn-ghost btn-sm">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { label: 'Эрээнд', value: stats.china, icon: Box, color: 'text-blue-600 bg-blue-50' },
            { label: 'Замд', value: stats.transit, icon: Truck, color: 'text-amber-600 bg-amber-50' },
            { label: 'УБ-д', value: stats.ub, icon: Package, color: 'text-violet-600 bg-violet-50' },
            { label: 'Авахад бэлэн', value: stats.ready, icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
            { label: 'Буцаалт', value: stats.pendingReturns, icon: AlertTriangle, color: stats.pendingReturns > 0 ? 'text-red-600 bg-red-50' : 'text-surface-600 bg-surface-50' },
          ].map(s => (
            <div key={s.label} className="card p-4">
              <div className={`w-9 h-9 rounded-xl ${s.color} flex items-center justify-center mb-2`}>
                <s.icon className="w-4.5 h-4.5" />
              </div>
              <div className="text-2xl font-bold text-surface-900">{s.value}</div>
              <div className="text-xs text-surface-400">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-4 gap-3">
          {[
            { label: 'Бараа хүлээн авах', icon: QrCode, href: '/staff/scanner', color: 'bg-zamex-600 text-white' },
            { label: 'Batch үүсгэх', icon: Truck, href: '/cargo/batches/new', color: 'bg-emerald-600 text-white' },
            { label: 'Хэмжилт хийх', icon: Scale, href: '/cargo/measure', color: 'bg-violet-600 text-white' },
            { label: 'Бараа олгох', icon: CheckCircle2, href: '/cargo/pickup', color: 'bg-amber-600 text-white' },
          ].map(a => (
            <button key={a.label} onClick={() => router.push(a.href)}
              className={`${a.color} rounded-2xl p-5 text-left hover:opacity-90 transition shadow-sm`}>
              <a.icon className="w-6 h-6 mb-2" />
              <div className="text-sm font-semibold">{a.label}</div>
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Recent Packages */}
          <div className="card">
            <div className="p-4 border-b border-surface-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-surface-900">Сүүлийн бараа</h3>
              <button onClick={() => router.push('/cargo/packages')} className="text-xs text-zamex-600 hover:underline">
                Бүгд →
              </button>
            </div>
            <div className="divide-y divide-surface-100">
              {packages.slice(0, 8).map(pkg => (
                <div key={pkg.id} className="px-4 py-3 flex items-center justify-between">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-surface-900 truncate">
                      {pkg.order?.orderCode || pkg.trackingNumber || pkg.id.slice(0, 8)}
                    </div>
                    <div className="text-xs text-surface-400">
                      {pkg.weightKg && `${pkg.weightKg}кг`} {pkg.category?.name && `• ${pkg.category.name}`}
                    </div>
                  </div>
                  <StatusBadge status={pkg.status} />
                </div>
              ))}
              {packages.length === 0 && (
                <div className="p-8 text-center text-sm text-surface-400">Бараа байхгүй</div>
              )}
            </div>
          </div>

          {/* Batches + Returns */}
          <div className="space-y-4">
            {/* Active Batches */}
            <div className="card">
              <div className="p-4 border-b border-surface-100 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-surface-900">Batch-ууд</h3>
                <button onClick={() => router.push('/cargo/batches')} className="text-xs text-zamex-600 hover:underline">
                  Бүгд →
                </button>
              </div>
              <div className="divide-y divide-surface-100">
                {batches.slice(0, 5).map(b => (
                  <div key={b.id} className="px-4 py-3 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-mono font-medium text-surface-900">{b.batchCode}</div>
                      <div className="text-xs text-surface-400">{b._count?.packages || b.totalPackages} бараа • {b.totalWeight}кг</div>
                    </div>
                    <StatusBadge status={b.status} />
                  </div>
                ))}
                {batches.length === 0 && (
                  <div className="p-6 text-center text-sm text-surface-400">Batch байхгүй</div>
                )}
              </div>
            </div>

            {/* Pending Returns */}
            {returns.length > 0 && (
              <div className="card border-l-4 border-l-red-400">
                <div className="p-4 border-b border-surface-100">
                  <h3 className="text-sm font-semibold text-red-700">
                    ⚠ Хүлээгдэж буй буцаалтууд ({returns.length})
                  </h3>
                </div>
                <div className="divide-y divide-surface-100">
                  {returns.slice(0, 5).map(r => (
                    <button key={r.id} onClick={() => router.push(`/cargo/returns/${r.id}`)}
                      className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-surface-50 transition">
                      <div>
                        <div className="text-sm font-medium text-surface-900">
                          {r.order?.orderCode} — {r.title}
                        </div>
                        <div className="text-xs text-surface-400">
                          {r.customer?.firstName} • {r.returnCode}
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-surface-300" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <div className="grid md:grid-cols-3 gap-3">
          {[
            { label: 'Бүх бараа', desc: 'Хайх, шүүх, хэмжих', icon: Package, href: '/cargo/packages' },
            { label: 'Нэхэмжлэх', desc: 'Үүсгэх, төлбөр хянах', icon: BarChart3, href: '/cargo/invoices' },
            { label: 'Харилцагчид', desc: 'Бүртгэл, кодууд', icon: Users, href: '/cargo/customers' },
            { label: 'Үнэлгээ', desc: 'Рейтинг, хариулах', icon: Star, href: '/cargo/ratings' },
            { label: 'Тохиргоо', desc: 'Тариф, workflow', icon: TrendingUp, href: '/cargo/settings' },
          ].map(nav => (
            <button key={nav.label} onClick={() => router.push(nav.href)}
              className="card-hover p-4 text-left flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-surface-50 text-surface-600 flex items-center justify-center flex-shrink-0">
                <nav.icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-surface-900">{nav.label}</div>
                <div className="text-xs text-surface-400">{nav.desc}</div>
              </div>
              <ChevronRight className="w-4 h-4 text-surface-300" />
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    RECEIVED_IN_CHINA: 'badge-blue', MEASURED: 'badge-blue', BATCHED: 'badge-blue',
    OPEN: 'badge-blue', CLOSED: 'badge-gray', LOADING: 'badge-yellow',
    DEPARTED: 'badge-yellow', IN_TRANSIT: 'badge-yellow',
    AT_CUSTOMS: 'badge-yellow', ARRIVED: 'badge-green', ARRIVED_MN: 'badge-green',
    READY_FOR_PICKUP: 'badge-green', DELIVERED: 'badge-gray',
    OPENED: 'badge-red', UNDER_REVIEW: 'badge-yellow', APPROVED: 'badge-green',
  };
  const labels: Record<string, string> = {
    RECEIVED_IN_CHINA: 'Ирсэн', MEASURED: 'Хэмжсэн', BATCHED: 'Batch-д',
    OPEN: 'Нээлттэй', CLOSED: 'Хаасан', DEPARTED: 'Замд',
    IN_TRANSIT: 'Замд', ARRIVED: 'Ирсэн', ARRIVED_MN: 'УБ-д',
    READY_FOR_PICKUP: 'Бэлэн', DELIVERED: 'Олгосон',
  };
  return (
    <span className={map[status] || 'badge-gray'}>
      {labels[status] || status}
    </span>
  );
}
